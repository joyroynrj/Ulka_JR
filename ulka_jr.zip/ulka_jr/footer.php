<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ulka_JR
 */

?>

	</div><!-- #content -->
</div><!-- #page -->

<footer>
<section class="footer-section-area">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="footer-widget wow fadeIn" data-wow-delay="0s">
                    <?php if ( is_active_sidebar( 'ulkajr_widget_first' )  ) : ?>
                        <?php dynamic_sidebar( 'ulkajr_widget_first' ); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-2 col-sm-6">
                <div class="footer-widget wow fadeIn" data-wow-delay="0.2s">
                    <?php if ( is_active_sidebar( 'ulkajr_widget_second' )  ) : ?>
                        <?php dynamic_sidebar( 'ulkajr_widget_second' ); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-7">
                <div class="footer-widget wow fadeIn clear" data-wow-delay="0.4s">
                    <?php if ( is_active_sidebar( 'ulkajr_widget_third' )  ) : ?>
                        <?php dynamic_sidebar( 'ulkajr_widget_third' ); ?>
                    <?php endif; ?>
                </div>
            </div>
            <!--------------
            <div class="col-md-3">
                <div class="footer-widget wow fadeIn" data-wow-delay="0.8s">
                    <?php if ( is_active_sidebar( 'ulkajr_widget_fourth' )  ) : ?>
                        <?php dynamic_sidebar( 'ulkajr_widget_fourth' ); ?>
                    <?php endif; ?>
                    <div class="footer-socials">
                        <?php 
                        $social = cs_get_option( 'social' ); 
                            if ( !empty($social) ) {
                            foreach ( $social as $socials ) {
                        ?>                                    
                            <a target="_blank" href="<?php echo $socials['social_url'];?>"><?php if ( $socials['social_icon'] ):?><i class="<?php echo $socials['social_icon'];?>" aria-hidden="true"></i><?php elseif( $socials['social_image'] ):?><img src="<?php echo wp_get_attachment_url( $socials['social_image'] ); ?>" alt=""><?php endif;?></a>
                            <?php }
                            }
                        ?>
                    </div>
                    
                </div>
            </div>
            -------------->
        </div>
    </div>
</section>

<section class="copyright-section">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="copyright-text center-text"><span> &copy; <?php echo get_the_date('Y'); ?> <?php echo cs_get_option('footer_copyright');?></span></div>
            </div>
        </div>
    </div>
</section>
	
</footer><!-- #colophon -->

<?php wp_footer(); ?>

</body>
</html>
