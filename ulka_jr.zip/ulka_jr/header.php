<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 *
 * @package Ulka_JR
 */

?>
<!DOCTYPE html>

<!--[if IE 8]>         <html class="no-js lt-ie9" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 9]>         <html class="no-js ie9" <?php language_attributes(); ?>> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" <?php language_attributes(); ?> style="margin:0px !important;" > <!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta property="fb:pages" content="568109180201574" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="icon" href="<?php echo wp_get_attachment_url(cs_get_option('favicon'));?>" type="image/png" sizes="16x16">
<?php wp_head(); ?>
<?php include('css/style.php');?>
	
<script type="application/ld+json">
{ "@context": "http://schema.org",
  "@type": "Product",
  "name": "BeLocal Today",
  "aggregateRating":
    {"@type": "AggregateRating",
     "ratingValue": "4.8",
     "reviewCount": "46"
    }
}
</script>	
	
</head>
<body <?php body_class(); ?>>
<!--
<div class="preloader">
    <div class="spinner">
        <div class="dot1"></div>
        <div class="dot2"></div>
    </div>
</div>
-->

<div id="page" class="site">
	<header id="masthead" class="site-header" role="banner">
		<section class="main-header-sec">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-3">
                         <a href="<?php echo esc_url( home_url() );?>" class="site-logo"><img src="<?php echo wp_get_attachment_url( cs_get_option('logo') ); ?>" alt=""></a>
                    </div>
                    <div class="col-xs-12 col-md-9 visible-md visible-lg">
                        <div class="main-nav">
                            <?php
                                wp_nav_menu( array(
                                    'menu'              => 'primary',
                                    'theme_location'    => 'primary',
                                    'container_id' => 'cssmenu', 
                                    'walker' => new CSS_Menu_Maker_Walker()   
                                ) );
                            ?>
                        </div>
                    </div>
                </div>
            </div>
		</section>
    <?php if ( is_front_page() ) : ?>
        <?php include('page-part/main_banner.php');?>
    <?php else:?>
    <div class="clear"></div>
    
     <div class="inner-banner" >
         <div class="container">
             <div class="row">
                 <div class="col-md-12">
                    <?php if( is_home() || is_single() ):?>
                        <h1>News</h1>
                    <?php else:?>
                        <h1><?php the_title();?></h1>
                    <?php endif;?>
                 </div>
             </div>
         </div>
     </div>
	<?php endif; ?>	
	</header><!-- #masthead -->

	<div id="content" class="site-content">
