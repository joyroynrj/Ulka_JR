<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Ulka_JR
 */

?>

<?php if(is_single()):?>
<div class="single-page-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <div class="single-page-title">
                        <h2><?php the_title( ); ?></h2>
                    </div>
                    <div class="single-post-img-area">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail('full', array('class' => 'img-responsive'));?>
                        <?php endif; ?>
                    </div>
                    <div class="entry-meta">
                        <?php ulka_jr_posted_on(); ?>
                    </div><!-- .entry-meta -->
                    <div class="entry-content">
                    <?php the_content( );?>
                </div><!-- .entry-content -->
                </article>
            </div>
        </div>
    </div>
</div>

<?php else:?>
<?php if ($wp_query->current_post % 2 == 0): ?>
<div class="row single-blog-post">
    <div class="col-md-6">
        <div class="single-post-img-area">
            <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                    <?php the_post_thumbnail('full', array('class' => 'img-responsive'));?>
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="single-post-content-area">
           <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
                </header><!-- .entry-header -->

                <div class="entry-meta">
                    <?php ulka_jr_posted_on(); ?>
                </div><!-- .entry-meta -->
                <div class="entry-content">
                    <?php echo wp_trim_words( get_the_content( ), 60 );?>
                </div><!-- .entry-content -->
                <div class="entry-readmore">
                    <a href="<?php the_permalink(); ?>">Read More...</a>
                </div>
            </article><!-- #post-## -->
        </div>
    </div>
</div>
<?php else:?>
<div class="row single-blog-post visible-ms visible-lg">
   <div class="col-md-6">
        <div class="single-post-content-area">
           <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
                </header><!-- .entry-header -->

                <div class="entry-meta">
                    <?php ulka_jr_posted_on(); ?>
                </div><!-- .entry-meta -->
                <div class="entry-content">
                    <?php echo wp_trim_words( get_the_content( ), 60 );?>
                </div><!-- .entry-content -->
                <div class="entry-readmore">
                    <a href="<?php the_permalink(); ?>">Read More...</a>
                </div>
            </article><!-- #post-## -->
        </div>
    </div>
    <div class="col-md-6">
        <div class="single-post-img-area">
            <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                    <?php the_post_thumbnail('full', array('class' => 'img-responsive'));?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="row single-blog-post visible-xs visible-sm">
    <div class="col-md-6">
        <div class="single-post-img-area">
            <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                    <?php the_post_thumbnail('full', array('class' => 'img-responsive'));?>
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="single-post-content-area">
           <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
                </header><!-- .entry-header -->

                <div class="entry-meta">
                    <?php ulka_jr_posted_on(); ?>
                </div><!-- .entry-meta -->
                <div class="entry-content">
                    <?php echo wp_trim_words( get_the_content( ), 60 );?>
                </div><!-- .entry-content -->
                <div class="entry-readmore">
                    <a href="<?php the_permalink(); ?>">Read More...</a>
                </div>
            </article><!-- #post-## -->
        </div>
    </div>
</div>
<?php endif?>
<?php endif;?>

