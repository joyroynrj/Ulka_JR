<?php
/**
 * The sidebar containing the page sidebar area
 * @package Ulka_JR
 */
?>
<?php if ( is_active_sidebar( 'ulkajr_sidebar' )  ) : ?>
	<div class="sidebar-area">
		<?php dynamic_sidebar( 'ulkajr_sidebar' ); ?>
	</div>
<?php endif; ?>