<?php
/**
 * Ulka_JR functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Ulka_JR
 */


add_action( 'admin_enqueue_scripts', 'custom_admin_scripts' );

function custom_admin_scripts() {
wp_register_script( 'admin-scripts', get_template_directory_uri() . '/js/admin-script.js', array(), '1.0', true );
 wp_enqueue_script('admin-scripts');

}


/************* WP Setup Functions  ***************/
require get_template_directory() . '/functions/setup_functions.php';


/************* WP Widget Functions  ***************/
require get_template_directory() . '/functions/widget_functions.php';

/************* WP Widget Functions  ***************/
require get_template_directory() . '/functions/js_css_functions.php';

/************* WP Custom Functions  ***************/
require get_template_directory() . '/functions/custom_functions.php';

/******    Codestar Option   ******/
require_once dirname( __FILE__ ) .'/lib/codestar/cs-framework.php';

/******    CMB2 Metabox Option   ******/
require_once dirname( __FILE__ ) .'/lib/CMB2/init.php';

/******    Aqua Resizer  ******/
require get_template_directory() . '/lib/aq_resizer.php';


/**********Implement the Custom Header feature.****/
require get_template_directory() . '/inc/custom-header.php';

/********* Custom template tags for this theme.*********/
require get_template_directory() . '/inc/template-tags.php';

/******* Custom functions that act independently of the theme templates.*******/
require get_template_directory() . '/inc/extras.php';

/********* Customizer additions*******/
require get_template_directory() . '/inc/customizer.php';

/******** Load Jetpack compatibility file. ********/
require get_template_directory() . '/inc/jetpack.php';

/******** Page functions ********/
require get_template_directory() . '/functions/page_function.php';


/******** Testimonial  file. ********/
require get_template_directory() . '/functions/post-type/testimonial-post.php';
require get_template_directory() . '/functions/shortcode/testimonial_shortcode_functions.php';


/******** Team  file. ********/
require get_template_directory() . '/functions/post-type/team-post.php';


/******** Gallery file. ********/
require get_template_directory() . '/functions/post-type/gallery.php';

/******** Page shortcode ********/
require get_template_directory() . '/functions/shortcode/page_shortcode.php';






