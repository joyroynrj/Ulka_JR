<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Ulka_JR
 */

get_header(); ?>
<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
        <section class="page-section-area">
            <div class="container">
                <div class="row">
                    <?php 
                    $page_layouts = get_post_meta( get_the_ID(), '_page_sidebar_layouts', true );
                    $fullwidth = $page_layouts ['page_sidebar_select'] == 'fullwidth';
                    $left_sidebar = $page_layouts ['page_sidebar_select'] == 'left_sidebar';
                    $right_sidebar = $page_layouts ['page_sidebar_select'] == 'right_sidebar'; 
                    ?>    
                    <?php if( $left_sidebar ):?>
                    <div class="col-xs-12 col-md-4">
                         <?php get_sidebar('page');?>
                    </div>
                    <?php endif;?>
                    <div class="col-xs-12 <?php if( $fullwidth ):?> col-md-12<?php else:?> col-md-8<?php endif;?>">
                        <?php while ( have_posts() ) : the_post();
                            get_template_part( 'template-parts/content', 'page' );
                         endwhile;?>

                    </div>
                    <?php if( $right_sidebar ):?>
                    <div class="col-xs-12 col-md-4">
                        <?php get_sidebar('page');?>
                    </div>
                    <?php endif;?>
                </div>
            </div>
        </section>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer();?>