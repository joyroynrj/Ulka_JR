<?php
//add_action( 'cmb2_admin_init', 'cmb2_home_page_quote_metaboxes' );
//function cmb2_home_page_quote_metaboxes() {
//
//}


//add_action( 'cmb2_admin_init', 'cmb2_single_page_metaboxes' );
//function cmb2_single_page_metaboxes() {
//
// 	$cmb = new_cmb2_box( array(
//		'id'           => 'single_page_banner',
//		'title'        => 'Single Page Banner',
//		'object_types' => array( 'page' ), // post type
//		'show_on_cb'        => 'add_conditions',
//		'show_on'      => array( 'key' => 'page-template', 'value' => array( 'default', 'page-template/vr-production-page.php', 'page-template/contact-page.php' ) ),
//		'context'      => 'normal', //  'normal', 'advanced', or 'side'
//		'priority'     => 'high',  //  'high', 'core', 'default' or 'low'
//		'show_names'   => true, // Show field names on the left
//	) );
//    
// 	$cmb->add_field( array(
//	'name'    => 'Single Page Banner Image',
//	'desc'    => 'Upload an image',
//	'id'      => 'single_page_banner_image',
//	'type'    => 'file',
//	// Optional:
//	'options' => array(
//		'url' => false, // Hide the text input for the url
//	),
//	'text'    => array(
//		'add_upload_file_text' => 'Add Banner Image' // Change upload button text. Default: "Add or Upload File"
//	),
//	'preview_size' => 'large', // Image size to use when previewing in the admin.
//	) );
//
//}
//





