
<?php
// Change admin footer text   

function remove_footer_admin ()   
{  
    echo '<span id="footer-thankyou">Thank you for creating with <a href="http://wordpress.org/" target="_blank">WordPress</a> and <a href="https://www.belocal.today" target="_blank">Belocal Today</a>.</span>';  
}  
add_filter('admin_footer_text', 'remove_footer_admin');


/************* WP nav walker  ***************/
require get_template_directory() . '/wp_menu_navwalker.php';


/************* Custom Class in media image  ***************/

function image_tag_class($class) {
    $class .= ' img-responsive';
    return $class;
}
add_filter('get_image_tag_class', 'image_tag_class' );



?>