<?php
function testimonial_slider_shortcode( $atts ) {
    extract( shortcode_atts( array(
        'testimonial_postorder' => '',
        'testimonial_postperpage' => ''
    ), $atts ) );
    $output = '
    <script>
    jQuery(document).ready(function($) { 
		$("#testimonial-slider").owlCarousel({
            autoplay:true,
            autoplayTimeout:4000,
            autoplayHoverPause:true,
            autoplaySpeed:8000,
            loop:true,
            responsiveClass:true,
            items:1,
            margin:0,
			responsive:{
				0:{items:1, nav:false, dots: true},
				600:{items:1, nav:false, dots: true},
				1000:{items:1, nav:true, dots: true}
			},
			lazyLoad: true,
			nav: true,
            navText: ["", ""],
			dots: true,
			dotData: true,
            singleItem: true,
		}); 
	}); 
    </script>
    <div id="testimonial-slider" class="owl-carousel">';
    $args = array(
        'post_type' => 'testimonials',
        'posts_per_page' => $testimonial_postperpage,
        'order'   => $testimonial_postorder
    );
    $i = 1;
    $j = 1;
    $jr_query = new  WP_Query( $args );
    while ( $jr_query->have_posts() ) : $jr_query->the_post();
    $testi_meta_name = get_post_meta( get_the_ID(), 'testi_meta_name', true ); 
        $output .= '<div class="item single-testimonial" href="#'.$i++.'!">'.
                   '<div class="single-testimonial-des">'. get_the_content(). '</div>'.
                    '<div class="single-testimonial-title"><p>'. get_the_title().'</p><span>'.get_post_meta( get_the_ID(), 'testi_meta_name', true ).'</span></div>'.
                   '</div><!--  ends here -->'; 
    endwhile;
    wp_reset_query();
    $output .= '</div>';
    $output .= '<style>';    
    while ( $jr_query->have_posts() ) : $jr_query->the_post();
    $output .= 'div#testimonial-slider .owl-dot:nth-child('.$j++.'){ background-image: url('. wp_get_attachment_url( get_post_thumbnail_id($post->ID,'thumbnail') ).');} ';
    endwhile;
    $output .= '</style>';
    wp_reset_query();
    
    return $output;
}
add_shortcode('testimonial_slider', 'testimonial_slider_shortcode');
?>
