<?php
 
function custom_faq_shortcode($atts){
    $list = '<div class="faq-area" >'; 
     extract( shortcode_atts( array(
        'faq_count' => '',
        'faq_order' => '',
    ), $atts) );
    $q = new WP_Query(
        array(
 
			'posts_per_page' => $faq_count,
			'post_type' => 'faqs',
			'order' => $faq_order,
			)
        ); 
        $i=1;     
    while($q->have_posts()) : $q->the_post();
        $idd = get_the_ID();
        $slide_meta = get_post_meta($idd, 'seo_slide_option', true);
        $list .= '
        
        <div class="single-faq">
            <div class="faq-counter">'.$i++.'</div>
            <div class="faq-detail">
          <h3>'.get_the_title($idd).'</h3>
          <p>'.wpautop(get_the_content($idd)).'</p>
          </div>
        </div>
        ';        
    endwhile;
    wp_reset_query();
     $list.= '</div>';
    return $list;
}
add_shortcode('faq_shortcodes', 'custom_faq_shortcode');

