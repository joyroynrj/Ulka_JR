<?php

function heading_title_shortcode( $atts ) {
    extract( shortcode_atts( array(
        'heading_title_text' => '',
    ), $atts ) );
    $output = '<header>'. $heading_title_text .'</header>';
     return $output;    
}
add_shortcode('heading_title', 'heading_title_shortcode');
?>