<?php
    add_shortcode( 'shortcodename', 'display_custom_post_type' );

    function display_custom_post_type(){
        $args = array(
            'post_type' => 'gallarys',
            'post_status' => 'publish'
        );

        $string = '';
        $query = new WP_Query( $args );
        if( $query->have_posts() ){
            $string .= '<ul>';
            while( $query->have_posts() ){
                $query->the_post();
                $string .= '<li>' . get_the_title() . '</li>';
            }
            $string .= '</ul>';
        }
        wp_reset_postdata();
        return $string;
    }
?>
