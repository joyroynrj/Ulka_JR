<?php
// Register gallery
function gallerys() {

	$labels = array(
		'name'                  => _x( 'Gallery', 'Post Type General Name', 'gallerys' ),
		'singular_name'         => _x( 'Gallery', 'Post Type Singular Name', 'gallerys' ),
		'menu_name'             => __( 'Gallery', 'gallerys' ),
		'name_admin_bar'        => __( 'Gallery', 'gallerys' ),
		'parent_item_colon'     => __( 'Parent Item:', 'gallerys' ),
		'all_items'             => __( 'All Gallery', 'gallerys' ),
		'add_new_item'          => __( 'Add New Gallery', 'gallerys' ),
		'add_new'               => __( 'Add New Gallery', 'gallerys' ),
		'new_item'              => __( 'New Gallery', 'gallery' ),
		'edit_item'             => __( 'Edit Gallery', 'gallery' ),
		'update_item'           => __( 'Update Gallery', 'gallery' ),
		'view_item'             => __( 'View Gallery', 'gallery' ),
		'search_items'          => __( 'Search Gallery', 'gallery' ),
		'not_found'             => __( 'Not found', 'gallery' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'gallery' ),
		'items_list'            => __( 'Gallery list', 'gallery' ),
		'items_list_navigation' => __( 'Gallery list navigation', 'gallery' ),
		'filter_items_list'     => __( 'Filter gallery list', 'gallery' ),
	);
	$rewrite = array(
		'slug'                  => 'gallerys',
		'with_front'            => false,
	);
	$args = array(
		'label'                 => __( 'Gallery', 'gallery' ),
		'labels'                => $labels,
		'supports'              => array( 'title' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => null,
		'menu_icon'             => 'dashicons-format-gallery',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'gallerys', $args );
    flush_rewrite_rules();
}
add_action( 'init', 'gallerys', 0 );

//Custom gallery

// Add to admin_init function
add_filter('manage_edit-gallerys_columns', 'add_new_gallerys_columns');
function add_new_gallerys_columns($gallerys_columns) {
$new_columns['cb'] = '<input type="checkbox" />';     
$new_columns['title'] = _x('gallery Title', 'column name');
$new_columns['thumbnail'] = __('gallery Shortcode', 'column name');
$new_columns['author'] = __('Author'); 
$new_columns['date'] = _x('Date', 'column name');

return $new_columns;
}


//Metabox fields

add_action( 'cmb2_admin_init', 'cmb2_gallerys_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function cmb2_gallerys_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'gallerys';

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'gallery_gallery',
        'title'         => __( 'gallery Information', 'cmb2' ),
        'object_types'  => array( 'gallerys', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );


    // Add other metaboxes as needed

    
    $cmb->add_field( array(
    'name' => 'gallerys Images',
    'desc' => 'Upload your gallery image here',
    'id'   => 'gallery_img',
    'type' => 'file_list',
    'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
    // Optional, override default text strings
    'text' => array(
        'add_upload_files_text' => 'Upload Files', // default: "Add or Upload Files"
        'remove_image_text' => 'Remove Image', // default: "Remove Image"
        'file_text' => 'File', // default: "File:"
        'file_download_text' => 'Download', // default: "Download"
        'remove_text' => 'Remove', // default: "Remove"
    ),
) );
}