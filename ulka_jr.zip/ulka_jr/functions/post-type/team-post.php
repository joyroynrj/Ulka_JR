<?php
// Register team
function team() {

	$labels = array(
		'name'                  => _x( 'Team', 'Post Type General Name', 'team' ),
		'singular_name'         => _x( 'Team', 'Post Type Singular Name', 'team' ),
		'menu_name'             => __( 'Team', 'team' ),
		'name_admin_bar'        => __( 'Team', 'team' ),
		'parent_item_colon'     => __( 'Parent Item:', 'team' ),
		'all_items'             => __( 'All Team', 'team' ),
		'add_new_item'          => __( 'Add New Team', 'team' ),
		'add_new'               => __( 'Add New Team', 'team' ),
		'new_item'              => __( 'New Team', 'team' ),
		'edit_item'             => __( 'Edit Team', 'team' ),
		'update_item'           => __( 'Update Team', 'team' ),
		'view_item'             => __( 'View Team', 'team' ),
		'search_items'          => __( 'Search Team', 'team' ),
		'not_found'             => __( 'Not found', 'team' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'team' ),
		'items_list'            => __( 'team list', 'team' ),
		'items_list_navigation' => __( 'team list navigation', 'team' ),
		'filter_items_list'     => __( 'Filter team list', 'team' ),
	);
	$rewrite = array(
		'slug'                  => 'team',
		'with_front'            => false,
	);
	$args = array(
		'label'                 => __( 'Team', 'team' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => null,
		'menu_icon'             => 'dashicons-groups',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'team', $args );
    flush_rewrite_rules();
}
add_action( 'init', 'team', 0 );

//Custom team

 // Add to admin_init function
add_filter('manage_edit-team_columns', 'add_new_team_columns');
function add_new_team_columns($team_columns) {
$new_columns['cb'] = '<input type="checkbox" />';     
$new_columns['title'] = _x('team Title', 'column name');
$new_columns['thumbnail'] = __('team Image', 'column name');
$new_columns['author'] = __('Author'); 
$new_columns['date'] = _x('Date', 'column name');

return $new_columns;
}
// Add to admin_init function
add_action('manage_team_posts_custom_column', 'manage_team_columns');

function manage_team_columns($column_name) {
//  global $wpdb;
    switch ($column_name) {
        case 'thumbnail':
            // echo get_the_post_thumbnail( $post->ID, array(35, 35) );
            echo get_the_post_thumbnail( get_the_ID(), array( 100, 100 ) );            
            break;
        default:
        break;
    } // end switch
} 

//Metabox fields

add_action( 'cmb2_admin_init', 'cmb2_team_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function cmb2_team_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'team';

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'team_meta',
        'title'         => __( 'Team Meta', 'cmb2' ),
        'object_types'  => array( 'team', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );

    // Add other metaboxes as needed
    
    $cmb->add_field( array(
    'name' => 'team designation',
    'id'   => 'team_designation',
    'type' =>  'text',
    ) );

}
