<?php

// Register courses
function courses() {

	$labels = array(
		'name'                  => _x( 'Course', 'Post Type General Name', 'courses' ),
		'singular_name'         => _x( 'Course', 'Post Type Singular Name', 'courses' ),
		'menu_name'             => __( 'Course', 'courses' ),
		'name_admin_bar'        => __( 'Course', 'courses' ),
		'parent_item_colon'     => __( 'Parent Item:', 'courses' ),
		'all_items'             => __( 'All Course', 'courses' ),
		'add_new_item'          => __( 'Add New Course', 'courses' ),
		'add_new'               => __( 'Add New', 'courses' ),
		'new_item'              => __( 'New Course', 'courses' ),
		'edit_item'             => __( 'Edit Course', 'courses' ),
		'update_item'           => __( 'Update Course', 'courses' ),
		'view_item'             => __( 'View Course', 'courses' ),
		'search_items'          => __( 'Search Course', 'courses' ),
		'not_found'             => __( 'Not found', 'courses' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'courses' ),
		'items_list'            => __( 'Course list', 'courses' ),
		'items_list_navigation' => __( 'Course list navigation', 'courses' ),
		'filter_items_list'     => __( 'Filter Course list', 'courses' ),
	);
	$rewrite = array(
		'slug'                  => 'courses',
		'with_front'            => false,
	);
	$args = array(
		'label'                 => __( 'Course', 'courses' ),
		'labels'                => $labels,
		'supports'              => array( 'title' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => null,
		'menu_icon'             => 'dashicons-media-code',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'courses', $args );
    flush_rewrite_rules();
}
add_action( 'init', 'courses', 0 );

 // Add to admin_init function
add_filter('manage_edit-courses_columns', 'add_new_courses_columns');
function add_new_courses_columns($courses_columns) {
$new_columns['cb'] = '<input type="checkbox" />';     
$new_columns['title'] = _x('courses Title', 'column name');
$new_columns['thumbnail'] = __('courses Image', 'column name');
$new_columns['author'] = __('Author'); 
$new_columns['date'] = _x('Date', 'column name');

return $new_columns;
}
// Add to admin_init function
add_action('manage_courses_posts_custom_column', 'manage_courses_columns');

function manage_courses_columns($column_name) {
//  global $wpdb;
    switch ($column_name) {
        case 'thumbnail':
            // echo get_the_post_thumbnail( $post->ID, array(35, 35) );
            echo get_the_post_thumbnail( get_the_ID(), array( 100, 100 ) );            
            break;
        default:
        break;
    } // end switch
} 

//Metabox fields

add_action( 'cmb2_admin_init', 'cmb2_courses_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function cmb2_courses_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'courses';

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'courses_meta',
        'title'         => __( 'Courses Meta', 'cmb2' ),
        'object_types'  => array( 'courses', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );

    // Add other metaboxes as needed
    
    
    $cmb->add_field( array(
	'name'    => 'Course Icon',
	'desc'    => 'Upload an icon.',
	'id'      => 'course_icon',
	'type'    => 'file',
	// Optional:
	'options' => array(
		'url' => false, // Hide the text input for the url
	),
	'text'    => array(
		'add_upload_file_text' => 'Add Icon' // Change upload button text. Default: "Add or Upload File"
	),
	'preview_size' => 'large', // Image size to use when previewing in the admin.
    ) );
    
    
    
    $cmb->add_field( array(
    'name' => 'Teacher Exprerience',
    'id'   => 'teacher_experience',
    'type' =>  'text',
    ) );
    $cmb->add_field( array(
    'name' => 'Teacher Course',
    'id'   => 'teacher_course',
    'type' =>  'text',
    ) );

}

