<?php
// Register Testimonial
function testimonials() {

	$labels = array(
		'name'                  => _x( 'Testimonials', 'Post Type General Name', 'testimonial' ),
		'singular_name'         => _x( 'Testimonials', 'Post Type Singular Name', 'testimonial' ),
		'menu_name'             => __( 'Testimonials', 'testimonial' ),
		'name_admin_bar'        => __( 'Testimonials', 'testimonial' ),
		'parent_item_colon'     => __( 'Parent Item:', 'testimonial' ),
		'all_items'             => __( 'All Testimonials', 'testimonial' ),
		'add_new_item'          => __( 'Add New Testimonial', 'testimonial' ),
		'add_new'               => __( 'Add New Testimonial', 'testimonial' ),
		'new_item'              => __( 'New Testimonial', 'testimonial' ),
		'edit_item'             => __( 'Edit Testimonial', 'testimonial' ),
		'update_item'           => __( 'Update Testimonial', 'testimonial' ),
		'view_item'             => __( 'View Testimonial', 'testimonial' ),
		'search_items'          => __( 'Search Testimonial', 'testimonial' ),
		'not_found'             => __( 'Not found', 'testimonial' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'testimonial' ),
		'items_list'            => __( 'testimonial list', 'testimonial' ),
		'items_list_navigation' => __( 'testimonial list navigation', 'testimonial' ),
		'filter_items_list'     => __( 'Filter testimonial list', 'testimonial' ),
	);
	$rewrite = array(
		'slug'                  => 'testimonial',
		'with_front'            => false,
	);
	$args = array(
		'label'                 => __( 'Testimonials', 'testimonial' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 40,
		'menu_icon'             => 'dashicons-editor-justify',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'testimonials', $args );
    flush_rewrite_rules();
}
add_action( 'init', 'testimonials', 0 );

//Custom testimonial

 // Add to admin_init function
add_filter('manage_edit-testimonials_columns', 'add_new_testimonials_columns');
function add_new_testimonials_columns($testimonials_columns) {
$new_columns['cb'] = '<input type="checkbox" />';     
$new_columns['title'] = _x('Testimonial Title', 'column name');
$new_columns['thumbnail'] = __('Testimonial Image', 'column name');
$new_columns['author'] = __('Author'); 
$new_columns['date'] = _x('Date', 'column name');

return $new_columns;
}
// Add to admin_init function
add_action('manage_testimonial_posts_custom_column', 'manage_testimonial_columns');

function manage_testimonial_columns($column_name) {
//  global $wpdb;
    switch ($column_name) {
        case 'thumbnail':
            // echo get_the_post_thumbnail( $post->ID, array(35, 35) );
            echo get_the_post_thumbnail( get_the_ID(), array( 100, 100 ) );            
            break;
        default:
        break;
    } // end switch
} 

//Metabox fields

add_action( 'cmb2_admin_init', 'cmb2_testimonials_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function cmb2_testimonials_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'testimonials';

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'testimonials_meta',
        'title'         => __( 'Testimonials Meta', 'cmb2' ),
        'object_types'  => array( 'testimonials', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );


    // Add other metaboxes as needed

    
    $cmb->add_field( array(
    'name' => 'Testimonial Meta Name',
    'id'   => 'testi_meta_name',
    'type' =>  'text',
) );
}
