<?php
// Register teacher
function teachers() {

	$labels = array(
		'name'                  => _x( 'Teachers', 'Post Type General Name', 'teacher' ),
		'singular_name'         => _x( 'Teachers', 'Post Type Singular Name', 'teacher' ),
		'menu_name'             => __( 'Teachers', 'teacher' ),
		'name_admin_bar'        => __( 'Teachers', 'teacher' ),
		'parent_item_colon'     => __( 'Parent Item:', 'teacher' ),
		'all_items'             => __( 'All Teachers', 'teacher' ),
		'add_new_item'          => __( 'Add New Teachers', 'teacher' ),
		'add_new'               => __( 'Add New Teachers', 'teacher' ),
		'new_item'              => __( 'New Teachers', 'teacher' ),
		'edit_item'             => __( 'Edit Teachers', 'teacher' ),
		'update_item'           => __( 'Update Teachers', 'teacher' ),
		'view_item'             => __( 'View Teachers', 'teacher' ),
		'search_items'          => __( 'Search Teachers', 'teacher' ),
		'not_found'             => __( 'Not found', 'teacher' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'teacher' ),
		'items_list'            => __( 'teacher list', 'teacher' ),
		'items_list_navigation' => __( 'teacher list navigation', 'teacher' ),
		'filter_items_list'     => __( 'Filter Teachers list', 'teacher' ),
	);
	$rewrite = array(
		'slug'                  => 'teacher',
		'with_front'            => false,
	);
	$args = array(
		'label'                 => __( 'Teachers', 'teacher' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => null,
		'menu_icon'             => 'dashicons-groups',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'teachers', $args );
    flush_rewrite_rules();
}
add_action( 'init', 'teachers', 0 );

//Custom teacher

 // Add to admin_init function
add_filter('manage_edit-teachers_columns', 'add_new_teachers_columns');
function add_new_teachers_columns($teachers_columns) {
$new_columns['cb'] = '<input type="checkbox" />';     
$new_columns['title'] = _x('Teachers Title', 'column name');
$new_columns['thumbnail'] = __('Teachers Image', 'column name');
$new_columns['author'] = __('Author'); 
$new_columns['date'] = _x('Date', 'column name');

return $new_columns;
}
// Add to admin_init function
add_action('manage_teacher_posts_custom_column', 'manage_teacher_columns');

function manage_teacher_columns($column_name) {
//  global $wpdb;
    switch ($column_name) {
        case 'thumbnail':
            // echo get_the_post_thumbnail( $post->ID, array(35, 35) );
            echo get_the_post_thumbnail( get_the_ID(), array( 100, 100 ) );            
            break;
        default:
        break;
    } // end switch
} 

//Metabox fields

add_action( 'cmb2_admin_init', 'cmb2_teachers_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function cmb2_teachers_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = 'teachers';

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'teachers_meta',
        'title'         => __( 'Teachers Meta', 'cmb2' ),
        'object_types'  => array( 'teachers', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );

    // Add other metaboxes as needed
    
    $cmb->add_field( array(
    'name' => 'Teacher Degree',
    'id'   => 'teacher_degree',
    'type' =>  'text',
    ) );
    $cmb->add_field( array(
    'name' => 'Teacher Exprerience',
    'id'   => 'teacher_experience',
    'type' =>  'text',
    ) );
    $cmb->add_field( array(
    'name' => 'Teacher Course',
    'id'   => 'teacher_course',
    'type' =>  'text',
    ) );

}
