<?php

// Register Service
function service() {

	$labels = array(
		'name'                  => _x( 'Service', 'Post Type General Name', 'service' ),
		'singular_name'         => _x( 'Service', 'Post Type Singular Name', 'service' ),
		'menu_name'             => __( 'Service', 'service' ),
		'name_admin_bar'        => __( 'Service', 'service' ),
		'parent_item_colon'     => __( 'Parent Item:', 'service' ),
		'all_items'             => __( 'All Service', 'service' ),
		'add_new_item'          => __( 'Add New Service', 'service' ),
		'add_new'               => __( 'Add New', 'service' ),
		'new_item'              => __( 'New Service', 'service' ),
		'edit_item'             => __( 'Edit Service', 'service' ),
		'update_item'           => __( 'Update Service', 'service' ),
		'view_item'             => __( 'View Service', 'service' ),
		'search_items'          => __( 'Search Service', 'service' ),
		'not_found'             => __( 'Not found', 'service' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'service' ),
		'items_list'            => __( 'Service list', 'service' ),
		'items_list_navigation' => __( 'Service list navigation', 'service' ),
		'filter_items_list'     => __( 'Filter Service list', 'service' ),
	);
	$rewrite = array(
		'slug'                  => '',
		'with_front'            => false,
	);
	$args = array(
		'label'                 => __( 'Service', 'service' ),
		'labels'                => $labels,
		'supports'              => array( 'title' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 6,
		'menu_icon'             => 'dashicons-media-code',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'service', $args );
    flush_rewrite_rules();
}
add_action( 'init', 'service', 0 );

 // Add to admin_init function
add_filter('manage_edit-service_columns', 'add_new_service_columns');
function add_new_service_columns($service_columns) {
$new_columns['cb'] = '<input type="checkbox" />';     
$new_columns['title'] = _x('Service Title', 'column name');
$new_columns['thumbnail'] = __('Service Image', 'column name');
$new_columns['author'] = __('Author'); 
$new_columns['date'] = _x('Date', 'column name');

return $new_columns;
}
// Add to admin_init function
add_action('manage_service_posts_custom_column', 'manage_service_columns');

function manage_service_columns($column_name) {
//  global $wpdb;
    switch ($column_name) {
        case 'thumbnail':
            // echo get_the_post_thumbnail( $post->ID, array(35, 35) );
            echo get_the_post_thumbnail( get_the_ID(), array( 100, 100 ) );            
            break;
        default:
        break;
    } // end switch
} 
