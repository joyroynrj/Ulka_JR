<?php
// Register FAQ
function faqs() {

	$labels = array(
		'name'                  => _x( 'FAQ', 'faqs' ),
		'singular_name'         => _x( 'FAQ', 'faqs' ),
		'menu_name'             => __( 'FAQ', 'faqs' ),
		'name_admin_bar'        => __( 'FAQ', 'faqs' ),
		'parent_item_colon'     => __( 'Parent Item:', 'faqs' ),
		'all_items'             => __( 'All FAQ', 'faqs' ),
		'add_new_item'          => __( 'Add New FAQ', 'faqs' ),
		'add_new'               => __( 'Add New', 'faqs' ),
		'new_item'              => __( 'New FAQ', 'faqs' ),
		'edit_item'             => __( 'Edit FAQ', 'faqs' ),
		'update_item'           => __( 'Update FAQ', 'faqs' ),
		'view_item'             => __( 'View FAQ', 'faqs' ),
		'search_items'          => __( 'Search FAQ', 'faqs' ),
		'not_found'             => __( 'Not found', 'faqs' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'faqs' ),
		'items_list'            => __( 'FAQ list', 'faqs' ),
		'items_list_navigation' => __( 'FAQ list navigation', 'faqs' ),
		'filter_items_list'     => __( 'Filter FAQ list', 'faqs' ),
	);
	$rewrite = array(
		'slug'                  => 'faqs',
		'with_front'            => false,
	);
	$args = array(
		'label'                 => __( 'FAQ', 'faqs' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor'),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => null,
		'menu_icon'             => 'dashicons-schedule',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'faqs', $args );
    flush_rewrite_rules();
}
add_action( 'init', 'faqs', 0 );

//Custom FAQ

 // Add to admin_init function
add_filter('manage_edit-faqs_columns', 'add_new_faqs_columns');
function add_new_faqs_columns($faqs_columns) {
$new_columns['cb'] = '<input type="checkbox" />';     
$new_columns['title'] = _x('FAQ Title', 'column name');
$new_columns['author'] = __('Author'); 
$new_columns['date'] = _x('Date', 'column name');

return $new_columns;
}
// Add to admin_init function
add_action('manage_faqs_posts_custom_column', 'manage_faqs_columns');





