<?php 
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ulka_jr_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'ulka_jr' ),
		'id'            => 'ulkajr_sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'ulka_jr' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
    register_sidebar( array(
		'name'          => esc_html__( 'Footer Widgets First', 'ulka_jr' ),
		'id'            => 'ulkajr_widget_first',
		'description'   => esc_html__( 'Add widgets here.', 'ulka_jr' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
    register_sidebar( array(
		'name'          => esc_html__( 'Footer Widgets Second', 'ulka_jr' ),
		'id'            => 'ulkajr_widget_second',
		'description'   => esc_html__( 'Add widgets here.', 'ulka_jr' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
     register_sidebar( array(
		'name'          => esc_html__( 'Footer Widgets Third', 'ulka_jr' ),
		'id'            => 'ulkajr_widget_third',
		'description'   => esc_html__( 'Add widgets here.', 'ulka_jr' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
     register_sidebar( array(
		'name'          => esc_html__( 'Footer Widgets Fourth', 'ulka_jr' ),
		'id'            => 'ulkajr_widget_fourth',
		'description'   => esc_html__( 'Add widgets here.', 'ulka_jr' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
     register_sidebar( array(
		'name'          => esc_html__( 'Footer Widgets Fifth', 'ulka_jr' ),
		'id'            => 'ulkajr_widget_fifth',
		'description'   => esc_html__( 'Add widgets here.', 'ulka_jr' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );    
}
add_action( 'widgets_init', 'ulka_jr_widgets_init' );
?>