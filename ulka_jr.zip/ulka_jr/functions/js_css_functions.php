<?php
/**
 * Enqueue scripts and styles.
 */
function ulka_jr_style() {
wp_enqueue_style( 'ulka_jr-owlcss', get_template_directory_uri() . '/inc/owl/css/owl.carousel.min.css', array(), '2.2.1', 'all' );
wp_enqueue_style( 'ulka_jr-fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.7.0', 'all' );
wp_enqueue_style( 'ulka_jr-gallerycss', get_template_directory_uri() . '/inc/lightgallery/css/lightgallery.min.css', array(), '1.2.19', 'all' );
wp_enqueue_style( 'ulka_jr-bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '3.3.7', 'all' );
wp_enqueue_style( 'ulka_jr-commoncss', get_template_directory_uri() . '/css/commoncss.css', array(), '0.1', 'all' );
wp_enqueue_style( 'ulka_jr-animate', get_template_directory_uri() . '/css/animate.min.css', array(), '3.5.1', 'all' );
wp_enqueue_style( 'ulka_jr-gfont', get_template_directory_uri() . '/fonts/Roboto.css', array(), 'all' );
wp_enqueue_style( 'ulka_jr-style', get_stylesheet_uri() );
wp_enqueue_style( 'ulka_jr-responsive', get_template_directory_uri() . '/css/responsive.css', array(), 'all' );
}
add_action( 'wp_enqueue_scripts', 'ulka_jr_style' );





if (!is_admin()) add_action("wp_enqueue_scripts", "my_jquery_enqueue", 11);
function my_jquery_enqueue() {
   wp_deregister_script('jquery');
   wp_register_script( 'jquery', get_template_directory_uri() . '/js/jquery.js', array(), '1.12.4', null ); 
//   wp_register_script('jquery', "http" . ($_SERVER['SERVER_PORT'] == 443 ? "s" : "") . "://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js", false, null);
   wp_enqueue_script('jquery');
}


function ulka_jr_script() {
wp_enqueue_script( 'ulka_jquery-migrate', get_template_directory_uri() . '/js/jquery-migrate.min.js', array(), '1.4.1', true );
wp_enqueue_script( 'ulka_jr-customjs', get_template_directory_uri() . '/js/custom.js', array(),'0.1', true ); 
wp_enqueue_script( 'ulka_jr-gallery-js', get_template_directory_uri() . '/inc/lightgallery/js/lightgallery.min.js', array(), '1.2.19', true );
wp_enqueue_script( 'ulka_jr-gallery-thumbnail-js', get_template_directory_uri() . '/inc/lightgallery/js/lg-thumbnail.min.js', array(), '1.2.19', true );
wp_enqueue_script( 'ulka_jr-bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '3.3.7', true );
wp_enqueue_script( 'ulka_jr-owljs', get_template_directory_uri() . '/inc/owl/js/owl.carousel.min.js', array(), '2.2.1', true );
wp_enqueue_script( 'ulka_jr-wow', get_template_directory_uri() . '/js/wow.min.js', array(), '1.3.0', true );   
}    
add_action( 'wp_enqueue_scripts', 'ulka_jr_script' );

?>