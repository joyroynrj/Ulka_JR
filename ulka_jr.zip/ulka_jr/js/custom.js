
(function ($) {
    "use strict";
    jQuery(document).ready(function () {
        new WOW().init();
    });

    
//    jQuery(window).on("load", function () {
//        //Custom Preloader
//        $('.preloader').fadeOut(300);
//    });
//
//    $('#lightgallery').lightGallery({
//       download:false, 
//        pager:false,
//        fullScreen:false,
//        actualSize:false,
//    }
//    );
//    

 })(jQuery);

//    $(document).ready(function() { 
//		$("#testimonial-slider").owlCarousel({
//            autoplay:true,
//            autoplayTimeout:4000,
//            autoplayHoverPause:true,
//            autoplaySpeed:8000,
//            loop:true,
//            responsiveClass:true,
//            items:1,
//            margin:0,
//			responsive:{
//				0:{items:1, nav:false, dots: true},
//				600:{items:1, nav:false, dots: true},
//				1000:{items:1, nav:true, dots: true}
//			},
//			lazyLoad: true,
//			nav: true,
//            navText:[
//              '<img src="<?php echo get_template_directory_uri(); ?>/img/left-arrow.png" class="img-responsive" />',
//              '<img src="<?php echo get_template_directory_uri(); ?>/img/right-arrow.png" class="img-responsive" />'
//            ],
//			dots: true,
//			dotData: true,
//            singleItem: true,
//		});     
//	}); 

