// this is a basic change function, you can improve it.
;(function ( $, window, document, undefined ) {
  'use strict';

  $(document).ready( function() {

    $('#page_template').change( function() {

      $('#course_page_optionss').hide();

      switch( $( this ).val() ) {
        case 'page-template/course-single-page.php':
          $('#course_page_optionss').show();
        break;

      }

    }).change();

  });

})( jQuery, window, document );