<?php



add_action( 'cmb2_admin_init', 'image_gallery_register_metabox' );
function image_gallery_register_metabox() {
    
global $options;
    
$thumb_lang_text = __( 'Thumbnail', 'image-gallery' );    
$masonry_lang_text = __( 'Masonry', 'image-gallery' );    
$slideshow_lang_text = __( 'Slideshow', 'image-gallery' );    
$filmstrip_lang_text = __( 'Filmstrip', 'image-gallery' );    
$carousel_lang_text = __( 'Carousel', 'image-gallery' );    
$lightbox_lang_text = __( 'Lightbox', 'image-gallery' );    
$isotope_lang_text = __( 'Isotope', 'image-gallery' );    
    
if(wug_get_option('enable_lightbox') == 2) {
    $thumbnail_item_text = '';
} else {
    $thumbnail_item_text = ' + '.$lightbox_lang_text.'';
}

if(wug_get_option('enable_owl') != 2) {
    if(wug_get_option('enable_maronry') != 2) {
        if(wug_get_option('enable_isotope') != 2) {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                                'masonry' => ''.$thumb_lang_text.' + '.$masonry_lang_text.''.$thumbnail_item_text.'',
                                'slideshow' => ''.$slideshow_lang_text.'',
                                'filmstrip' => ''.$filmstrip_lang_text.'',
                                'carousel' => ''.$carousel_lang_text.'',
                                'isotope' => ''.$isotope_lang_text.'',
                             ); 
        } else {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                                'masonry' => ''.$thumb_lang_text.' + '.$masonry_lang_text.''.$thumbnail_item_text.'',
                                'slideshow' => ''.$slideshow_lang_text.'',
                                'filmstrip' => ''.$filmstrip_lang_text.'',
                                'carousel' => ''.$carousel_lang_text.'',
                             );
        }
    } else {
        if(wug_get_option('enable_isotope') != 2) {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                                'slideshow' => ''.$slideshow_lang_text.'',
                                'filmstrip' => ''.$filmstrip_lang_text.'',
                                'carousel' => ''.$carousel_lang_text.'',
                                'isotope' => ''.$isotope_lang_text.'',
                             ); 
        } else {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                                'slideshow' => ''.$slideshow_lang_text.'',
                                'filmstrip' => ''.$filmstrip_lang_text.'',
                                'carousel' => ''.$carousel_lang_text.'',
                             );    
        }
    }
    
} else {
    if(wug_get_option('enable_maronry') != 2) {
        if(wug_get_option('enable_isotope') != 2) {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                                'masonry' => ''.$thumb_lang_text.' + '.$masonry_lang_text.''.$thumbnail_item_text.'',
                                'isotope' => ''.$isotope_lang_text.'',
                             );    
        } else {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                                'masonry' => ''.$thumb_lang_text.' + '.$masonry_lang_text.''.$thumbnail_item_text.'',
                             );         
        }
    } else {
        if(wug_get_option('enable_isotope') != 2) {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                                'isotope' => ''.$isotope_lang_text.'',
                             );  
        } else {
            $view_as_array = array(
                                'thumbnail' => ''.$thumb_lang_text.''.$thumbnail_item_text.'',
                             );  
        }
            
    }    
}

if(wug_get_option('enable_lightbox') == 2) {
    $carousel_link_behabour_array = array(
                                        'large_size_image' => 'Link to large size image',
                                        'external_link' => 'External link only',
                                        'no_link' => 'No link',
                                    );  
} else {    
    $carousel_link_behabour_array = array(
                                        'lightbox' => 'Link to lightbox image or video',
                                        'external_link' => 'External link only',
                                        'no_link' => 'No link',
                                    );  
}
    
    
    
	$image_gallery_metabox = new_cmb2_box( array(
		'id'            => 'wp_ug_metabox_id',
		'title'         => __( 'Configure Gallery', 'image-gallery' ),
		'object_types'  => array( 'image-gallery', )
	) );
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Upload Images', 'image-gallery'),
        'desc'          => __('Upload gallery images here. You can upload all at once.', 'image-gallery'),
        'id'          => 'images',
        'type'        => 'file_list',
    ) );
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('View as', 'image-gallery'),
        'desc'          => __('Select how you want to view gallery.', 'image-gallery'),
        'id'          => 'view_as',
        'type'        => 'radio',
        'default'        => 'thumbnail',
        'options'        => $view_as_array,
    ) );
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Isotope menu items', 'image-gallery'),
        'desc'          => __('Type Isotope menu items comma seprated. Make sure you used those on image tags.<span style="color:#E74C3C">Do not use space before or after comma</span>', 'image-gallery'),
        'id'          => 'isotope_menu_items',
        'type'        => 'text',
    ) );     
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Carousel width', 'image-gallery'),
        'desc'          => __('Select carousel width in px. Don\'t worry, slideshow will responsive. This is just used for image crop. Numbers only.', 'image-gallery'),
        'id'          => 'carousel_width',
        'type'        => 'text',
        'default'        => '600',
    ) );      
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Carousel height', 'image-gallery'),
        'desc'          => __('Select carousel height in px. Don\'t worry, slideshow will responsive. This is just used for image crop. Numbers only.', 'image-gallery'),
        'id'          => 'carousel_height',
        'type'        => 'text',
        'default'        => '450',
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Gallery width', 'image-gallery'),
        'desc'          => __('Select filmstrip gallery width in px. Don\'t worry, slideshow will responsive. This is just used for image crop. Numbers only.', 'image-gallery'),
        'id'          => 'filmstrip_width',
        'type'        => 'text',
        'default'        => '800',
    ) );      
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Gallery height', 'image-gallery'),
        'desc'          => __('Select filmstrip gallery height in px. Don\'t worry, slideshow will responsive. This is just used for image crop. Numbers only.', 'image-gallery'),
        'id'          => 'filmstrip_height',
        'type'        => 'text',
        'default'        => '500',
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Slideshow width', 'image-gallery'),
        'desc'          => __('Select slideshow width in px. Don\'t worry, slideshow will responsive. This is just used for image crop. Numbers only.', 'image-gallery'),
        'id'          => 'slideshow_width',
        'type'        => 'text',
        'default'        => '1140',
    ) );      
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Slideshow height', 'image-gallery'),
        'desc'          => __('Select slideshow height in px. Don\'t worry, slideshow will responsive. This is just used for image crop. Numbers only.', 'image-gallery'),
        'id'          => 'slideshow_height',
        'type'        => 'text',
        'default'        => '450',
    ) ); 
    
  
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Images per row', 'image-gallery'),
        'desc'          => __('If you select flexible here, it will take 160px width each image & display columns automatically with your page container width. Alternatively, you can select images per row.', 'image-gallery'),
        'id'          => 'per_row_images',
        'default'          => 'flexible',
        'type'        => 'radio',
        'options'        => array(
            'flexible' => __('Flexible', 'image-gallery'),
            '1_image' => __('1 Image per row', 'image-gallery'),
            '2_image' => __('2 Images per row', 'image-gallery'),
            '3_image' => __('3 Images per row', 'image-gallery'),
            '4_image' => __('4 Images per row', 'image-gallery'),
            '6_image' => __('6 Images per row', 'image-gallery'),
        ),
    ) );
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Images order', 'image-gallery'),
        'desc'          => __('Select images order here. <strong>Asending</strong> means images will show images order above & <strong>Desending</strong> means reverse.', 'image-gallery'),
        'id'          => 'images_order',
        'type'        => 'radio',
        'default'        => 'asending',
        'options'        => array(
            'asending' => __('Ascending', 'image-gallery'),
            'desending' => __('Descending', 'image-gallery')
        ),
    ) );    
    
    
    if(wug_get_option('enable_infinite') != 2) {
        $image_gallery_metabox->add_field( array(
            'name'          => __('Enable AJAX navigation?', 'image-gallery'),
            'desc'          => __('If you want to enable AJAX pagination on gallery, select yes here.', 'image-gallery'),
            'id'          => 'ajax_pagination',
            'type'        => 'radio',
            'default'        => 'false',
            'options'        => array(
                'false' => __('No', 'image-gallery'),
                'true' => __('Yes', 'image-gallery')
            ),
        ) );
    }
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Images per page', 'image-gallery'),
        'desc'          => __('Type a number how many images will show per page. Numbers only.', 'image-gallery'),
        'id'          => 'per_page',
        'type'        => 'text',
        'default'        => '12',
    ) );
    
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Enable autoplay?', 'image-gallery'),
        'desc'          => __('If you want to enable autoplay, select Yes here.', 'image-gallery'),
        'id'          => 'owl_autoplay',
        'type'        => 'radio',
        'default'        => 'true',
        'options'        => array(
            'true' => __('Yes', 'image-gallery'),
            'false' => __('No', 'image-gallery'),
        ),
    ) );
    
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Autoplay Time', 'image-gallery'),
        'desc'          => __('Set autoplay time here.', 'image-gallery'),
        'id'          => 'owl_autoplay_time',
        'default'          => '5',
        'type'        => 'text',
    ) );
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Enable loop?', 'image-gallery'),
        'desc'          => __('If you want loop infinite, select Yes here.', 'image-gallery'),
        'id'          => 'owl_loop',
        'type'        => 'radio',
        'default'        => 'true',
        'options'        => array(
            'true' => __('Yes', 'image-gallery'),
            'false' => __('No', 'image-gallery'),
        ),
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Enable navigation arrows', 'image-gallery'),
        'desc'          => __('If you want enable next previous arrow, select Yes here.', 'image-gallery'),
        'id'          => 'owl_nav',
        'type'        => 'radio',
        'default'        => 'false',
        'options'        => array(
            'true' => __('Yes', 'image-gallery'),
            'false' => __('No', 'image-gallery'),
        ),
    ) );
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Enable bullets?', 'image-gallery'),
        'desc'          => __('If you want enable bullets, select Yes here.', 'image-gallery'),
        'id'          => 'owl_dots',
        'type'        => 'radio',
        'default'        => 'true',
        'options'        => array(
            'true' => __('Yes', 'image-gallery'),
            'false' => __('No', 'image-gallery'),
        ),
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Carousel items per row', 'image-gallery'),
        'desc'          => __('Select carousel items per row', 'image-gallery'),
        'id'          => 'owl_items',
        'type'        => 'text',
        'default'        => '5',
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Carousel tablet items per row', 'image-gallery'),
        'desc'          => __('Select carousel tablet items per row', 'image-gallery'),
        'id'          => 'owl_items_tablet',
        'type'        => 'text',
        'default'        => '3',
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Carousel mobile items per row', 'image-gallery'),
        'desc'          => __('Select carousel mobile items per row', 'image-gallery'),
        'id'          => 'owl_items_mobile',
        'type'        => 'text',
        'default'        => '1',
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Carousel items margin', 'image-gallery'),
        'desc'          => __('Type items between margin in px. Numbers only.', 'image-gallery'),
        'id'          => 'owl_margin',
        'type'        => 'text',
        'default'        => '30',
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Gallery thumbnail count', 'image-gallery'),
        'desc'          => __('Type how many thumbnail item you want to show. Numbers only.', 'image-gallery'),
        'id'          => 'filmstrip_thumbnail_item',
        'type'        => 'text',
        'default'        => '10',
    ) );
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Gallery thumbnail margin', 'image-gallery'),
        'desc'          => __('Type thumbnail items between margin in px. Numbers only.', 'image-gallery'),
        'id'          => 'filmstrip_thumbnail_margin',
        'type'        => 'text',
        'default'        => '5',
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Carousel item link behabour', 'image-gallery'),
        'desc'          => __('Select carousel items link behabour here.', 'image-gallery'),
        'id'          => 'carousel_link_behabour',
        'type'        => 'radio',
        'default'        => 'external_link',
        'options'        => $carousel_link_behabour_array,
    ) );  
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Enable caption?', 'image-gallery'),
        'desc'          => __('If you want to enable caption, select Yes here.', 'image-gallery'),
        'id'          => 'gallery_caption',
        'type'        => 'radio',
        'default'        => 'false',
        'options'        => array(
            'true' => __('Yes', 'image-gallery'),
            'false' => __('No', 'image-gallery'),
        ),
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Select caption field', 'image-gallery'),
        'desc'          => __('Which field will show as caption? Select here.', 'image-gallery'),
        'id'          => 'gallery_caption_field',
        'type'        => 'radio',
        'default'        => 'desc',
        'options'        => array(
            'title' => __('Title', 'image-gallery'),
            'caption' => __('Caption', 'image-gallery'),
            'desc' => __('Description', 'image-gallery'),
            'alttext' => __('Alt Text', 'image-gallery'),
        ),
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Enable full sized image?', 'image-gallery'),
        'desc'          => __('If you want to enable full sized image, select Yes here.', 'image-gallery'),
        'id'          => 'img_fullsize',
        'type'        => 'radio',
        'default'        => 'false',
        'options'        => array(
            'true' => __('Yes', 'image-gallery'),
            'false' => __('No', 'image-gallery'),
        ),
    ) ); 
    
    $image_gallery_metabox->add_field( array(
        'name'          => __('Enable preloader?', 'image-gallery'),
        'desc'          => __('If you want to enable preloader, select Yes here.', 'image-gallery'),
        'id'          => 'gallery_preloader',
        'type'        => 'radio',
        'default'        => 'true',
        'options'        => array(
            'true' => __('Yes', 'image-gallery'),
            'false' => __('No', 'image-gallery'),
        ),
    ) );     
};
