<?php

// Gallery custom messages
add_filter( 'post_updated_messages', 'image_gallery_updated_messages' );
function image_gallery_updated_messages( $messages ){
        
    global $post;
    
    $post_ID = $post->ID;
    
    $ug_img_count = image_gallery_image_count_admin_column($post_ID);
    if($ug_img_count < 1) {
        $messages['image-gallery'] = array(
            0 => '', 
            1 => __('Gallery updated. Upload images to generate shortcode.', 'image-gallery'),
            2 => __('Gallery field updated.', 'image-gallery'),
            3 => __('Gallery field deleted.', 'image-gallery'),
            4 => __('Gallery updated.'),
            5 => isset($_GET['revision']) ? sprintf( __('Gallery restored to revision from %s', 'image-gallery'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
            6 => __('Gallery published. Upload images to generate shortcode.', 'image-gallery'),
            7 => __('Gallery saved.', 'image-gallery'),
            8 => sprintf( __('Gallery submitted.', 'image-gallery'), esc_url( add_query_arg( 'preview', 'true',get_permalink($post_ID) ) ) ),
            9 => sprintf( __('Gallery scheduled for: <strong>%1$s</strong>.', 'image-gallery'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
            10 => sprintf( __('Gallery draft updated.', 'image-gallery'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
        );
    } else {
        $messages['image-gallery'] = array(
            0 => '', 
            1 => sprintf( __('Gallery updated. Shortcode is: %s', 'image-gallery'), '[image_gallery id="'.$post_ID.'"]' ),
            2 => __('Gallery field updated.', 'image-gallery'),
            3 => __('Gallery field deleted.', 'image-gallery'),
            4 => __('Gallery updated.', 'image-gallery'),
            5 => isset($_GET['revision']) ? sprintf( __('Gallery restored to revision from %s', 'image-gallery'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
            6 => sprintf( __('Gallery published. Shortcode is: %s', 'image-gallery'), '[image_gallery id="'.$post_ID.'"]' ),
            7 => __('Gallery saved.'),
            8 => sprintf( __('Gallery submitted.', 'image-gallery'), esc_url( add_query_arg( 'preview', 'true',get_permalink($post_ID) ) ) ),
            9 => sprintf( __('Gallery scheduled for: <strong>%1$s</strong>.', 'image-gallery'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
            10 => sprintf( __('Gallery draft updated.', 'image-gallery'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
        );
    }
    
    return $messages;
        
}