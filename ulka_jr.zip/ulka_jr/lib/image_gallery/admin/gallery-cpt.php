<?php

// Registering custom post type
add_action( 'init', 'image_gallery_cpt' );
function image_gallery_cpt() {
    register_post_type( 'image-gallery',
        array(
            'labels' => array(
                'name' => __( 'Galleries', 'image-gallery' ),
                'singular_name' => __( 'Gallery', 'image-gallery' )
            ),
            'supports' => array('title'),
            'menu_icon' => 'dashicons-format-gallery',
            'public' => false,
            'show_ui' => true,
        )
    );
}