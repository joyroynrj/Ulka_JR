<?php
/**
 *
 * Codestar Framework Example Widget
 *
 */
if( ! class_exists( 'CS_Widget' ) ) {
  class CS_Widget extends WP_Widget {

    function __construct() {

      $widget_ops     = array(
        'classname'   => 'cs_widget_example',
        'description' => 'Codestar Framework Example Widget.'
      );

      parent::__construct( 'cs_widget', 'Footer Info', $widget_ops );

    }

    function widget( $args, $instance ) {

      extract( $args );

      echo $before_widget;

      if ( ! empty( $instance['title'] ) ) {
        echo $before_title . $instance['title'] . $after_title;
      }

      echo '<div class="textwidget footer-info-widget">';
        echo '<p>'. $instance['content'] .'</p>';
      echo '<div class="single-footer-info"><div class="footer-info-icon"><img src="'. wp_get_attachment_url($instance['address_icon']) .'" /></div>';
         echo '<div class="footer-info-body">'. $instance['address'] .'</div></div>';
      echo '<div class="single-footer-info"><div class="footer-info-icon"><img src="'. wp_get_attachment_url($instance['phone_icon']) .'" /></div>';
         echo '<div class="footer-info-body"><a href="tel:'.$instance['phone_number'].'">'. $instance['phone_number'] .'</a></div></div>';
      echo '<div class="single-footer-info"><div class="footer-info-icon"><img src="'. wp_get_attachment_url($instance['email_icon']) .'" /></div>';
         echo '<div class="footer-info-body"><a href="mailto:'.$instance['email'].'">'. $instance['email'] .'</a></div></div>';
      echo '</div>';

      echo $after_widget;

    }

    function update( $new_instance, $old_instance ) {

      $instance            = $old_instance;
      $instance['title']   = $new_instance['title'];
      $instance['address_icon']    = $new_instance['address_icon'];
      $instance['address']   = $new_instance['address'];
      $instance['phone_icon']    = $new_instance['phone_icon'];
      $instance['phone_number']   = $new_instance['phone_number'];
      $instance['email_icon']    = $new_instance['email_icon'];
      $instance['email']   = $new_instance['email'];
      $instance['content'] = $new_instance['content'];

      return $instance;

    }

    function form( $instance ) {

      //
      // set defaults
      // -------------------------------------------------
      $instance   = wp_parse_args( $instance, array(
        'title'   => 'About Us',
        'address_icon'    => '',
        'address'    => '',
        'phone_icon' => '',
        'phone_number' => '',
        'email_icon' => '',
        'email' => '',
        'content' => '',
      ));

      //
      // text field example
      // -------------------------------------------------
      $text_value = esc_attr( $instance['title'] );
      $text_field = array(
        'id'    => $this->get_field_name('title'),
        'name'  => $this->get_field_name('title'),
        'type'  => 'text',
        'title' => 'Title',
      );

      echo cs_add_element( $text_field, $text_value );
        //
      // textarea field example
      // -------------------------------------------------
      $textarea_value = esc_attr( $instance['content'] );
      $textarea_field = array(
        'id'    => $this->get_field_name('content'),
        'name'  => $this->get_field_name('content'),
        'type'  => 'textarea',
        'title' => 'Short About Description',
        'info'  => 'Some description for this field',
      );

      echo cs_add_element( $textarea_field, $textarea_value );
        
      //
      // Address icon field example
      // -------------------------------------------------
      $address_icon_value = esc_attr( $instance['address_icon'] );
      $address_icon_field = array(
        'id'    => $this->get_field_name('address_icon'),
        'name'  => $this->get_field_name('address_icon'),
        'type'  => 'image',
        'title' => 'Address Icon',
        'desc'  => 'Address Icon',
      );

      echo cs_add_element( $address_icon_field, $address_icon_value );
        
    //
    // Address field example
    // -------------------------------------------------
    $address_value = esc_attr( $instance['address'] );
    $address_field = array(
    'id'    => $this->get_field_name('address'),
    'name'  => $this->get_field_name('address'),
    'type'  => 'text',
    'title' => 'Address',
    );    
    echo cs_add_element( $address_field, $address_value );
 
        
    //
    // Phone icon field example
    // -------------------------------------------------
    $phone_icon_value = esc_attr( $instance['phone_icon'] );
    $phone_icon_field = array(
    'id'    => $this->get_field_name('phone_icon'),
    'name'  => $this->get_field_name('phone_icon'),
    'type'  => 'image',
    'title' => 'Phone Icon',
    'desc'  => 'Phone Icon',
    );

    echo cs_add_element( $phone_icon_field, $phone_icon_value );
    
    //
    // Phone  field example
    // -------------------------------------------------
    $phone_number_value = esc_attr( $instance['phone_number'] );
    $phone_number_field = array(
    'id'    => $this->get_field_name('phone_number'),
    'name'  => $this->get_field_name('phone_number'),
    'type'  => 'text',
    'title' => 'Phone Number',
    );    
    echo cs_add_element( $phone_number_field, $phone_number_value );    
        
        
        
    //
    // Email field example
    // -------------------------------------------------
    $email_icon_value = esc_attr( $instance['email_icon'] );
    $email_icon_field = array(
    'id'    => $this->get_field_name('email_icon'),
    'name'  => $this->get_field_name('email_icon'),
    'type'  => 'image',
    'title' => 'Email Icon',
    'desc'  => 'Email Icon',
    );

    echo cs_add_element( $email_icon_field, $email_icon_value );
        
    //
    // Phone  field example
    // -------------------------------------------------
    $email_value = esc_attr( $instance['email'] );
    $email_field = array(
    'id'    => $this->get_field_name('email'),
    'name'  => $this->get_field_name('email'),
    'type'  => 'text',
    'title' => 'Email ID',
    );    
    echo cs_add_element( $email_field, $email_value );       

    }
  }
}

if ( ! function_exists( 'cs_widget_init' ) ) {
  function cs_widget_init() {
    register_widget( 'CS_Widget' );
  }
  add_action( 'widgets_init', 'cs_widget_init', 2 );
}