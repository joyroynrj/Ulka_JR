<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings           = array(
  'menu_title'      => 'Theme Option',
  'menu_type'       => 'theme', // menu, submenu, options, theme, etc.
  'menu_slug'       => 'jr-framework',
  'ajax_save'       => true,
  'show_reset_all'  => false,
  'framework_title' => 'Ulka Option <small>by Joy Roy</small>',
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();

// ----------------------------------------
// a option section for options overview  -
// ----------------------------------------
$options[]      = array(
  'name'        => 'genaral_part',
  'title'       => 'Genaral Information',
  'icon'        => 'fa fa-star',
  'sections' => array(
	array(
  // begin: fields
	'name'      => 'basic_info',
    'title'     => 'Basic Information',
    'icon'      => 'fa fa-check',
    'fields'      => array(
    // begin: a field
	array(
      'id'      => 'favicon',
      'type'    => 'image',
      'title'   => 'Theme Favicon Icon',
      'help'    => 'Upload your site favicon icon.',
    ),
    array(
      'id'      => 'logo',
      'type'    => 'image',
      'title'   => 'Theme Logo',
      'help'    => 'Upload a site logo for your branding.',
    ), 
	  array(
        'id'        => 'website_font',
        'type'      => 'typography_advanced',
        'title'     => __('Website Typography', ''),
        'attributes'    => array(
          'title'   => __('Line Height', 'cs-framework'),
        ),
        'default'   => array(
          'family'  => 'Indie Flower',
          'variant' => 'regular',
          'font'    => 'google',
          'size'    => '18',
          'height'  => '18',
          'color'   => '#000'
        ),
        'preview'   => true, //Enable or disable preview box
        //'preview_text' => 'hello world', //Replace preview text with any text you like.
      ),
	array(
      'id'      => 'phone',
      'type'    => 'text',
      'title'   => 'Phone Number',
      'help'    => 'Put here your phone number.',
    ), 
    array(
      'id'      => 'fax',
      'type'    => 'text',
      'title'   => 'Fax Number',
      'help'    => 'Put here your Fax number.',
    ),
      
	array(
      'id'      => 'email',
      'type'    => 'text',
      'title'   => 'Email ID',
      'help'    => 'Put here your email Id.',
    ),
	
	array(
      'id'      => 'address',
      'type'    => 'text',
      'title'   => 'Address Location',
      'help'    => 'Put here your address.',
    ),
	array(
      'id'      => 'contact_map_img',
      'type'    => 'image',
      'title'   => 'Contact Map Image',
      'help'    => 'Upload Map Image',
    ),
	array(
      'id'      => 'map_url',
      'type'    => 'text',
      'title'   => 'Contact Map Url',
    ),

  ), // end: fields
  ),
  array(
    'name'     => 'social_media',
    'title'    => 'Social Media',
    'icon'     => 'fa fa-plus-circle',
    'fields'      => array(
  // Social Media Fields
     array(
        'id'              => 'social',
        'type'            => 'group',
        'title'           => 'Social Media',
        'desc'            => 'Pur here your social media information.',
        'button_title'    => 'Social Item',
        'accordion_title' => 'Social Item List',
        'fields'          => array(
        array(
        'id'          => 'social_name',
        'type'        => 'text',
        'title'       => 'Social Item Name',
        ),
        array(
        'id'          => 'social_url',
        'type'        => 'text',
        'title'       => 'Social Url',
        ),
        array(
        'id'         => 'social_icon_switch',
        'type'       => 'switcher',
        'title'      => 'Social Icon',
        'default'    => true
        ),
        array(
        'id'    => 'social_icon',
        'type'  => 'icon',
        'title' => 'Icon Field',
        'dependency' => array( 'social_icon_switch', '==', 'true' ) // dependency rule
        ),
        array(
        'id'    => 'social_image',
        'type'  => 'image',
        'title' => 'Social Image',
        'dependency' => array( 'social_icon_switch', '==', 'false' ) // dependency rule
        ),
        )
    ),
// Social Media Fields end  
      
) 
)

  )
);


// ------------------------------
// Header section area   -
// ------------------------------
$options[]   = array(
  'name'     => 'header_area',
  'title'    => 'Header Area',
  'icon'     => 'fa fa-plus-circle',
  'sections' => array(

      
    array(
        'name'      => 'topbar_section',
        'title'     => 'Topbar Section',
        'wrap_class' => 'topbar-section-area',
        'icon'      => 'fa fa-check',
            'fields' => array(
                 array(
                'id'      => 'topbar_background',
                'type'    => 'color_picker',
                'title'   => 'Header Background',
                'default' => '#ffffff',
                'rgba'    => true
                ),

                array(
                'id'    => 'topbar_padtop',
                'type'  => 'number',
                'title' => 'Padding Top',
                'after'   => ' <i class="cs-text-muted">(px)</i>',
                ),
                array(
                'id'    => 'topbar_padbottom',
                'type'  => 'number',
                'title' => 'Padding Bottom',
                'after'   => ' <i class="cs-text-muted">(px)</i>',
                ),   
            ),
    ),  //end topbar sec
    
    array(
      'name'      => 'header_section',
      'title'     => 'Header Section',
      'icon'      => 'fa fa-check',

      // begin: fields
      'fields'    => array(
         array(
                'id'      => 'header_background',
                'type'    => 'color_picker',
                'title'   => 'Header Background',
                'default' => '#ffffff',
                'rgba'    => true
        ),

        array(
        'id'    => 'header_padtop',
        'type'  => 'number',
        'title' => 'Padding Top',
        'default' => '10',
        'after'   => ' <i class="cs-text-muted">(px)</i>',
        ),
        array(
        'id'    => 'header_padbottom',
        'type'  => 'number',
        'title' => 'Padding Bottom',
        'default' => '10',
        'after'   => ' <i class="cs-text-muted">(px)</i>',
        ),   
      ), // end: fields

    ),   
      
    ) 
);


// ------------------------------
// Banner section area   -
// ------------------------------
$options[]   = array(
    'name'     => 'banner_section',
    'title'    => 'Banner Section',
    'icon'     => 'fa fa-film',
    'fields'   => array(
                array(
                'id'         => 'banner_slider_switch',
                'type'       => 'switcher',
                'title'      => 'Banner Slider Switch',
                'default'    => false
                ),
                array(
                'id'    => 'single_banner_image',
                'type'  => 'image',
                'title' => 'Banner Image',
                'dependency' => array( 'banner_slider_switch', '==', 'false' ) // dependency rule
                ),
                array(
                  'id'       => 'banner_caption',
                  'type'     => 'wysiwyg',
                  'title'    => 'Banner Captions',
                  'settings' => array(
                    'textarea_rows' => 3,
                    'tinymce'       => true,
                    'media_buttons' => false,
                    
                  ),
                  'dependency' => array( 'banner_slider_switch', '==', 'false' )
                ),
        
        
                
               array(
                      'id'              => 'banner_field',
                      'type'            => 'group',
                      'title'           => 'Banner Slider',
                      'dependency' => array( 'banner_slider_switch', '==', 'true' ), // dependency rule
                      'button_title'    => 'Add Banner',
                      'accordion_title' => 'Add New Banner',
                      'fields'          => array(
                        array(
                          'id'    => 'banner_title',
                          'type'  => 'text',
                          'title' => 'Banner Title',
                        ),
                        array(
                          'id'    => 'banner_image',
                          'type'  => 'image',
                          'title' => 'Banner Image',
                        ),
                        array(
                          'id'    => 'banner_switch',
                          'type'  => 'switcher',
                          'title' => 'More Fields',
                          'default'=> false,
                        ),
                         array(
                          'id'       => 'banner_captions',
                          'type'     => 'textarea',
                          'title'    => 'Banner Captions',
                          'dependency' => array( 'banner_switch', '==', 'true' )
                        ),  

                      ),
                    ),
      
    ) 
);

// ------------------------------
// Page section area   -
// ------------------------------
$options[]   = array(
    'name'     => 'page_section',
    'title'    => 'Page Section',
    'icon'     => 'fa fa-list',
    'sections' => array(
        

       
    //testimonial section    
    array(
      'name'      => 'testimonial_section',
      'title'     => 'Testimonial Section',
      'icon'      => 'fa fa-hand-o-right',
      'fields'   => array(
        array(
          'id'    => 'testimonial_switch',
          'type'  => 'switcher',
          'title' => 'Testimonial Section Switch',
          'default'=> false,
        ),
        array(
          'id'           => 'testimonial_bg',
          'type'         => 'background',
          'title'        => 'Testimonial Background',
          'dependency' => array( 'testimonial_switch', '==', 'true' ),
          'default'      => array(
            'image'      => get_template_directory_uri() .'/img/testimonial_bg.png',
            'repeat'     => 'no-repeat',
            'position'   => 'center center',
            'attachment' => 'fixed',
            'size'       => 'cover',
            'color'      => '',
          ),
        ),  
    ),
    ),
)
);




// ------------------------------
// Footer section area   -
// ------------------------------
$options[]   = array(
    'name'     => 'footer_section',
    'title'    => 'FooterSection',
    'icon'     => 'fa fa-flag-o',
    'fields'   => array(
        array(
        'id'          => 'footer_logo',
        'type'        => 'image',
        'title'       => 'Footer Logo',
        ),
        
        array(
        'id'          => 'footer_copyright',
        'type'        => 'text',
        'title'       => 'Footer Copyright Text',
        'default'   =>  'UlkaJR Theme Development',
        ),
         array(
        'id'      => 'copyright_background',
        'type'    => 'color_picker',
        'title'   => 'Footer Copyright Background',
        'default' => '#ffffff',
        'rgba'    => true
        ),
        array(
        'id'      => 'copyright_color',
        'type'    => 'color_picker',
        'title'   => 'Footer Copyright Text Color',
        'default' => '#000000'
        ),
        
        array(
        'id'    => 'copyright_padtop',
        'type'  => 'number',
        'default' => '10',
        'title' => 'Padding Top',
        'after'   => ' <i class="cs-text-muted">(px)</i>',
        ),
        array(
        'id'    => 'copyright_padbottom',
        'type'  => 'number',
        'default' => '10',
        'title' => 'Padding Bottom',
        'after'   => ' <i class="cs-text-muted">(px)</i>',
        ),
    ) 
);
CSFramework::instance( $settings, $options );
