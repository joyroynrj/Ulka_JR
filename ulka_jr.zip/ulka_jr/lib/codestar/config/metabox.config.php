<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();


// -----------------------------------------
// Page Side Metabox Options               -
// -----------------------------------------
$options[]    = array(
  'id'        => '_page_sidebar_layouts',
  'title'     => 'Page sidebar Layouts',
  'post_type' => 'page',
  'context'   => 'side',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'sidebar_layout',
      'fields' => array(

        array(
          'id'        => 'page_sidebar_select',
          'type'      => 'image_select',
          'options'   => array(
            'fullwidth' => get_template_directory_uri() .'/img/fullwidth_layout.jpg',
            'left_sidebar' => get_template_directory_uri() .'/img/leftsidebar_layout.jpg',
            'right_sidebar' => get_template_directory_uri() .'/img/rightsidebar_layout.jpg',
          ),
          'default'   => 'fullwidth',
        ),
        ),
      ),
    ),

);


// // -----------------------------------------
// // Page Metabox Options                    -
// // -----------------------------------------
// $options[]    = array(
//   'id'        => 'page_options',
//   'title'     => 'Page Options',
//   'post_type' => 'page', // <-------------- PAGE
//   'show_on'      => array( 'key' => 'id', 'value' => array( 37, 15 ) ),
//   'context'   => 'normal',
//   'priority'  => 'default',
//   'sections'  => array(
//       // begin section
//     array(
//       'name'      => 'single_page_banner',
//       'title'     => 'Single Page Banner',
//       'fields'    => array(
//         // a field
//         array(
//           'id'    => 'single_page_banner_image',
//           'type'  => 'text',
//           'title' => 'Single Page Banner Image',
//         ),
//
//       ),
//     ),
//     ),
// );


 // -----------------------------------------
 // Course Page Metabox Options                    -
 // -----------------------------------------
 $options[]    = array(
   'id'        => 'course_page_optionss',
   'title'     => 'Course Page Options',
   'post_type' => 'page', // <-------------- PAGE
   'show_on'      => array( 'key' => 'template', 'value' => array( 'page-template/course-single-page.php' ) ),
   'context'   => 'normal',
   'priority'  => 'high',
   'sections'  => array(
       // begin section
    array(
        'name'  =>  'course_icon_field',
        'title'  =>  'Course Icon',
        'fields'  =>  array(
            array(
                'id' => 'couse_icon',
                'type' => 'image',
                'title' => 'Course icon',
            ),
        ),
    ),   
       
     array(
       'name'      => 'course_class_info',
       'title'     => 'Class Info',
       'fields'    => array(
         // a field
         array(
           'id'    => 'course_start_date',
           'type'  => 'text',
           'title' => 'Start Date',
         ),
           
         array(
           'id'    => 'course_class_duration',
           'type'  => 'text',
           'title' => 'Class Duration',
         ),
        array(
           'id'    => 'course_level',
           'type'  => 'text',
           'title' => 'Level',
         ),
        array(
           'id'    => 'course_year_old',
           'type'  => 'text',
           'title' => 'Years Old',
         ),
        array(
           'id'    => 'course_seat_available',
           'type'  => 'text',
           'title' => 'Seat Available',
        ),
        array(
           'id'    => 'course_price',
           'type'  => 'text',
           'title' => 'Seat Price',
        ),
       ),
     ),
    array(
       'name'      => 'course_tab-info',
       'title'     => 'Course Tab Information',
       'fields'    => array(
            array(
              'id'       => 'course_description',
              'type'     => 'wysiwyg',
              'title'    => 'Course Description',
              'settings' => array(
                'textarea_rows' => 5,
                'tinymce'       => true,
                'media_buttons' => false,
              )
            ),
            array(
              'id'       => 'course_info',
              'type'     => 'wysiwyg',
              'title'    => 'Course Info',
              'settings' => array(
                'textarea_rows' => 5,
                'tinymce'       => true,
                'media_buttons' => false,
              )
            ),
            array(
              'id'       => 'course_teacher',
              'type'     => 'wysiwyg',
              'title'    => 'Course Teacher',
              'settings' => array(
                'textarea_rows' => 5,
                'tinymce'       => true,
                'media_buttons' => false,
              )
            ),
            
        ),
        ),

     ),
 );











CSFramework_Metabox::instance( $options );