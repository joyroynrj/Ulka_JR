<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// SHORTCODE GENERATOR OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options       = array();

// -----------------------------------------
// Faq Shortcode Examples                -
// -----------------------------------------

$options[]  = array(
    'title' => 'FAQ Shortcode Area',
    'shortcodes'    => array(
        array(
            'name'  => 'faq_shortcodes',
            'title' => 'FAQ Shorcode',
            'fields' => array(
                array(
                    'title' => 'FAQ Count',
                    'id'    => 'faq_count',
                    'type'  => 'text'
                ),
                array(
                    'title' => 'FAQ Order',
                    'id'    => 'faq_order',
                    'type'     => 'select',
                    'options'  => array(
                        'desc'  => 'Decembly',
                        'asc'   => 'Assembly',
                    ),
                    'default'  => 'desc',
                ),
            ) ,
        ),
    ),
);

// -----------------------------------------
// Faq Shortcode Examples                -
// -----------------------------------------

$options[]  = array(
    'title' => 'Testimonial Shortcode Area',
    'shortcodes'    => array(
        array(
            'name'  => 'testimonial_slider',
            'title' => 'Testimonial Slider Shorcode',
            'fields' => array(
                array(
                    'title' => 'Post Per Page',
                    'id'    => 'testimonial_postperpage',
                    'type'  => 'number',
                    'default' => '5'
                ),
                array(
                    'title' => 'Testimonial Order',
                    'id'    => 'testimonial_postorder',
                    'type'     => 'select',
                    'options'  => array(
                        'desc'  => 'Decembly',
                        'asc'   => 'Assembly',
                    ),
                    'default'  => 'desc',
                ),
            ) ,
        ),
    ),
);

$options[]  = array(
    'title' => 'Heading Title Shortcode',
    'shortcodes'    => array(
        array(
            'name'  => 'heading_title',
            'title' => 'Heading Title',
            'fields' => array(
                array(
                    'title' => 'Title Text',
                    'id'    => 'heading_title_text',
                    'type'  => 'text',
                ),
            ) ,
        ),
    ),
);



CSFramework_Shortcode_Manager::instance( $options );
