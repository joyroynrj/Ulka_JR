<style>
 <?php  $testimonial_bg=cs_get_option('testimonial_bg');?> 
 <?php  $website_font=cs_get_option('website_font');?> 

body{font-family:<?php echo $website_font['family'];?>; font-weight: <?php echo $website_font['variant'];?>; font-size: <?php echo $website_font['size'];?>px; line-height:<?php echo $website_font['height'];?>; color: <?php echo $website_font['color'];?> }  
    
    .header-topbar{ background-color: <?php echo cs_get_option('topbar_background');?>;padding-top: <?php echo cs_get_option('topbar_padtop');?>px; padding-bottom: <?php echo cs_get_option('topbar_padbottom');?>px;}    
    .main-header-sec{background-color: <?php echo cs_get_option('header_background');?>; padding-top: <?php echo cs_get_option('header_padtop');?>px; padding-bottom: <?php echo cs_get_option('header_padbottom');?>px;}
    .copyright-section{background-color: <?php echo cs_get_option('copyright_background');?>; color: <?php echo cs_get_option('copyright_color');?>; padding-top: <?php echo cs_get_option('copyright_padtop');?>px; padding-bottom: <?php echo cs_get_option('copyright_padbottom');?>px;}
/*    .inner-banner{background-image: url(<//?php echo get_post_meta( get_the_ID(), 'single_page_banner_image', true );?>);}    */
    .testimonial-section{background-image: url(<?php echo $testimonial_bg['image'];?>); background-repeat: <?php echo $testimonial_bg['repeat'];?>; background-position: <?php echo $testimonial_bg['position'];?>; background-size: <?php echo $testimonial_bg['size'];?>; background-color: <?php echo $testimonial_bg['color'];?>;}
    .mv-bg-image{background-image: url(<?php echo wp_get_attachment_url(cs_get_option('mv_img'));?>);}
     .contact-map-area{background-image: url(<?php echo wp_get_attachment_url(cs_get_option('contact_map_img'));?>);}
    .banner-image{background-image: url(<?php echo wp_get_attachment_url(cs_get_option('single_banner_image')); ?>);}
</style>


