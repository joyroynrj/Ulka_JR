<?php if(cs_get_option( 'testimonial_switch' ) == true):?>
<section class="testimonial-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="testimonial-area">
                   <div class="testimonial-icon"><img src="<?php echo get_template_directory_uri();?>/img/testimonial_icon.png" alt=""></div>
                    <?php echo do_shortcode('[testimonial_slider testimonial_postorder="ASC"]');?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif;?>