<?php if(cs_get_option( 'portfolio_switch' ) == true):?>
<section class="home-project-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="home-project-title-des  wow fadeInUp">
                    <h1>Our Portfolio</h1>
                    <p><?php echo cs_get_option( 'portfolio_head_description' );?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="project-gallery">
       <div id="project-carousel" class="owl-carousel">
        <?php
        global $post;
        $args = array(
        'post_type' => 'projects',
        'posts_per_page' => -1,
        'order'=>'DESC'
        );
        $i = 0;
        $loop = new WP_Query($args);
        if ($loop->have_posts()) : while ($loop->have_posts()) : $loop->the_post(); ?>
		<?php
        $project_img = get_post_meta( $post->ID, 'project_img',1 );
        foreach ( $project_img as $attachment_id => $imgs ) { 
            $image_thumbnail = aq_resize( $imgs, 400, 307, true );
            $img_meta = wp_prepare_attachment_for_js ($attachment_id);                        
        ?> 
            <div class="item">
            	<div class="grid">
	            	<figure class="effect-bubba">
	                	<img class="img-responsive" src="<?php echo $image_thumbnail;?>" alt=""> 
	                	<figcaption>
								<h2><?php echo $img_meta['title'];?></h2>
								<p>Read More</p>
								<a href="<?php echo home_url();?>/portfolio">View more</a>
						</figcaption>
	                </figure>
                </div>
            </div>
        <?php } ?>
        <?php endwhile; endif;?> 
        </div>
    </div>
    <div class="full-project-btn">
    	<a href="<?php echo home_url();?>/portfolio"><span>view all projects</span></a>
    </div>
</section>

<script>
	
	jQuery(document).ready(function($) { 
		$("#project-carousel").owlCarousel({
            autoplay:true,
            autoplayTimeout:4000,
            autoplayHoverPause:true,
            autoplaySpeed:8000,
            loop:true,
            responsiveClass:true,
            items:5,
            margin:0,
			responsive:{
				0:{items:1, nav:false, dots: false},
				600:{items:2, nav:false, dots: false},
				1000:{items:5, nav:false, dots: false}
			},
			lazyLoad: true,
			nav: false,
           navText:[
             '<i class="fa fa-long-arrow-left" aria-hidden="true"></i>',
             '<i class="fa fa-long-arrow-right" aria-hidden="true"></i>'
           ],
			dots: false,
			dotData: false,
            singleItem: true,
		});     
	});   
</script>
<?php endif;?>
