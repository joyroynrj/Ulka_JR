<?php if(cs_get_option( 'course_switch' ) == true):?>
<section class="course-section">
   
    <?php  $course_title = cs_get_option( 'course_head_title' ); ?>
    <?php  $course_description = cs_get_option( 'course_head_description' ); ?>
  
   <div class="container">
       <div class="row">
           <div class="col-md-12">
               <div class="heading-title wow fadeInUp" data-wow-delay="0s">
                   <span><?php echo $course_title?></span>
               </div>
               <div class="heading-description wow fadeInUp" data-wow-delay="0.2s">
                   <p><?php echo $course_description;?></p>
               </div>
               <div class="course-area">
                   <div class="row">
                        <?php
                        $work_group = cs_get_option( 'course_group' );
                        $i = 0;
                        foreach ( $work_group as $key => $work_groups ) { ?> 
                            <div class="col-md-3 col-sm-6 course-hover wow fadeInUp" data-wow-delay="0.<?php echo $i+=2;?>s">
                              <?php $pages = get_pages(); ?>
                               <div class="single-course">
                                   <?php if(cs_get_option( 'course_page_link' ) == !true):?>
                                        
                                            <div class="single-course-icon">
                                               <img src="<?php echo wp_get_attachment_url( $work_groups['course_icon'] );?>" alt="">
                                            </div>
                                            <div class="single-course-details">
                                               <h4><?php echo $work_groups['course_title'];?></h4>
                                            </div>
                                        
                                    <?php else:?>
                                        <a href="<?php echo get_page_link( $work_groups['course_page'] );?>">
                                            <div class="single-course-icon">
                                               <img src="<?php echo wp_get_attachment_url( $work_groups['course_icon'] );?>" alt="">
                                            </div>
                                            <div class="single-course-details">
                                               <h4><?php echo $work_groups['course_title'];?></h4>
                                            </div>
                                       </a>
                                    <?php endif;?>
                               </div>
                            </div>
                        <?php } ?>
                   </div>
               </div>
           </div>
       </div>
   </div>
</section>
<?php endif;?>