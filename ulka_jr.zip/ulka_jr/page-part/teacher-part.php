<?php if(cs_get_option( 'teacher_switch' ) == true):?>
<?php  $teacher_title = cs_get_option( 'teacher_heading_title' ); ?>
<?php  $teacher_description = cs_get_option( 'teacher_heading_description' ); ?>
<section class="teacher-section-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-title wow fadeInUp" data-wow-delay="0s">
                   <span><?php echo $teacher_title?></span>
               </div>
               <div class="heading-description wow fadeInUp" data-wow-delay="0.2s">
                   <p><?php echo $teacher_description;?></p>
               </div>
            </div>
        </div>
            <div id="teacher-slider" class="owl-carousel">
            <?php
            $args = array(
                'post_type' => 'teachers',
                'posts_per_page' => 4,
                'order'   => 'ASC'
            );
            $i = 1;
            $j = 1;
            $jr_query = new  WP_Query( $args );
            while ( $jr_query->have_posts() ) : $jr_query->the_post();
            $img_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID,'thumbnail') );
            $teacher_degree = get_post_meta( get_the_ID(), 'teacher_degree', true );     
            $teacher_experience = get_post_meta( get_the_ID(), 'teacher_experience', true );     
            $teacher_course = get_post_meta( get_the_ID(), 'teacher_course', true );     
            ?>
                <div class="single-teacher">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="teacher-img">
                                <img src="<?php echo $img_url;?>" class="img-responsive" alt="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="single-teacher-info">
                                <div class="teacher-title">
                                    <h3><?php echo get_the_title()?></h3>
                                </div>
                                <div class="teacher-meta">
                                    <p><span>Degree:</span> <?php echo $teacher_degree;?></p>
                                    <p><span>Experience:</span> <?php echo $teacher_experience;?></p>
                                    <p><span>My Courses:</span> <?php echo $teacher_course;?></p>
                                </div>
                                <div class="teacher-des">
                                    <?php echo get_the_content();?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; wp_reset_query();?>
            </div>
            <style>
                <?php while ( $jr_query->have_posts() ) : $jr_query->the_post();?>
                    div#teacher-slider .owl-dot:nth-child(<?php echo $j++; ?>){ background-image: url(<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID,'thumbnail') );?>);}
                <?php endwhile; wp_reset_query();?>
            </style>
    </div>
</section>





 <script>
    jQuery(document).ready(function($) { 
		$("#teacher-slider").owlCarousel({
            autoplay:true,
            autoplayTimeout:4000,
            autoplayHoverPause:true,
            autoplaySpeed:8000,
            loop:true,
            responsiveClass:true,
            items:1,
            margin:0,
			responsive:{
				0:{items:1, nav:false, dots: true},
				600:{items:1, nav:false, dots: true},
				1000:{items:1, nav:true, dots: true}
			},
			lazyLoad: true,
			nav: false,
            navText: ["", ""],
			dots: true,
			dotData: true,
            singleItem: true,
		}); 
	}); 
    </script>
<?php endif;?>

