<section class="gallery-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="gallery-sec-title  wow fadeInUp">
                    <h2>Gallery</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row" id="lightgallery">
        <?php
        global $post;
        $args = array(
        'post_type' => 'gallerys',
        'posts_per_page' => -1,
        'order'=>'DESC'
        );
        $i = 0;
        $loop = new WP_Query($args);
        if ($loop->have_posts()) : while ($loop->have_posts()) : $loop->the_post(); ?>
		<?php
        $gallery_img = get_post_meta( $post->ID, 'gallery_img',1 );
        foreach ( $gallery_img as $attachment_id => $imgs ) { 
            $image_thumbnail = aq_resize( $imgs, 500, 400, true );
            $img_meta = wp_prepare_attachment_for_js ($attachment_id);                        
        ?> 
            <div class="col-sm-6 col-md-4" data-responsive="<?php echo $imgs; ?>" data-src="<?php echo $imgs; ?>" data-sub-html="<p></p>">
            	<div class="grid single-gallery wow fadeIn" data-wow-delay=".<?php echo $i+=3;?>s">
	            	<figure class="effect-bubba">
	                	<img class="img-responsive img-full" src="<?php echo $image_thumbnail;?>" alt=""> 
	                	<figcaption>
								<img class="zoom-icon" src="<?php echo get_template_directory_uri();?>/img/zoom.png" alt="">
						</figcaption>
	                </figure>
                </div>

            </div>
        <?php } ?>
        <?php endwhile; endif;?> 
    </div>
    </div>

    <script>
        jQuery(document).ready(function($){
            $('#lightgallery').lightGallery({
               download:false, 
                pager:false,
                fullScreen:false,
                actualSize:false,
            }
            );
        });
    </script>

</section>
