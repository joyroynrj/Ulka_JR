<?php if(cs_get_option( 'training_switch' ) == true):?>
<?php  $training_title = cs_get_option( 'training_heading_title' ); ?>
<?php  $training_description = cs_get_option( 'training_heading_description' ); ?>
   <section class="training-secion-area">
    <div class="container">
           <div class="heading-title wow fadeInUp" data-wow-delay="0s">
               <span><?php echo $training_title?></span>
           </div>
           <div class="heading-description wow fadeInUp" data-wow-delay="0.2s">
               <p><?php echo $training_description;?></p>
           </div>
       
       
       
        <div class="training-area col-md-12">
            <?php
            $training_group = cs_get_option( 'training_group' );
            $i = 2;
            $j = 0;
            foreach ( $training_group as $key => $training_groups ) { ?>

               <?php if($i%2==0):?>
                <div class="single-training">
                <div class="row" >
                    <div class="col-md-6 training-img-bg" >
                        <div class="wow fadeIn" data-wow-delay=".0s">
                        <div class="single-training-img">
                            <img class="img-responsive center-block" src="<?php echo wp_get_attachment_url( $training_groups['training_icon'] );?>" alt="">
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6 ">
                       <div class="single-training-info wow fadeIn" data-wow-delay=".2s">
                        <div class="single-training-title">
                            <span><h3><?php echo $training_groups['training_title'];?></h3></span>
                        </div>
                        <div class="single-training-des">
                            <?php echo $training_groups['training_description'];?>
                        </div>
                        <div class="single-training-btn">
                            <a href="#"><span>Read More...</span></a>
                        </div>
                        </div>
                    </div>
                </div>
                </div>
                <?php else:?>
                <div class="single-training">
                <div class="row">
                   <div class="col-md-6 training-img-bg visible-xs visible-sm">
                       <div class="wow fadeIn" data-wow-delay=".6s">
                        <div class="single-training-img">
                            <img class="img-responsive center-block" src="<?php echo wp_get_attachment_url( $training_groups['training_icon'] );?>" alt="">
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="single-training-info  wow fadeIn" data-wow-delay=".4s">
                        <div class="single-training-title">
                            <span><h3><?php echo $training_groups['training_title'];?></h3></span>
                        </div>
                        <div class="single-training-des">
                            <?php echo $training_groups['training_description'];?>
                        </div>
                        <div class="single-training-btn">
                            <a href=""><span>Read More...</span></a>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6 training-img-bg visible-md visible-lg">
                       <div class="wow fadeIn" data-wow-delay=".6s">
                        <div class="single-training-img">
                            <img class="img-responsive center-block" src="<?php echo wp_get_attachment_url( $training_groups['training_icon'] );?>" alt="">
                        </div>
                        </div>
                    </div>
                </div>
                </div>
                <?php endif;?>
                <?php $i++;?>
            <?php } ?> 
        </div>
    </div>
</section>
<?php endif;?>
