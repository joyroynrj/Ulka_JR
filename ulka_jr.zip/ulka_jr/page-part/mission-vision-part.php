<section class="mision-vision-section">
    <div class="container-fluid">
        <div class="row">
            <div class="mv-bg-image mv-clear col-md-6">
<!--                <img class="img-responsive" src="<?php echo wp_get_attachment_url(cs_get_option('mv_img'));?>" alt="">-->
            </div>
            <div class="mv-clear col-md-6">
                <div class="mv-area">
                    <div class="single-mv" >
                        <div class="single-mv-icon wow fadeIn" data-wow-delay="0s">
                            <img src="<?php echo wp_get_attachment_url(cs_get_option('mision_icon'));?>" alt="">
                        </div>
                        <div class="single-mv-info wow fadeIn" data-wow-delay="0.2s">
                           <h3>Mission</h3>
                            <p><?php echo cs_get_option('mision_description');?></p>
                        </div>
                    </div>
                    <div class="single-mv">
                        <div class="single-mv-icon wow fadeIn" data-wow-delay="0.4s">
                            <img src="<?php echo wp_get_attachment_url(cs_get_option('vision_icon'));?>" alt="">
                        </div>
                        <div class="single-mv-info wow fadeIn" data-wow-delay="0.6s">
                           <h3>Vision</h3>
                            <p><?php echo cs_get_option('vision_description');?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>