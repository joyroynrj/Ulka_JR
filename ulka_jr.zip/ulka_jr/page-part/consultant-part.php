<section class="consultant-part-section">
    <div class="container">
        <div class="row">
           <div class="col-md-12"><header class="wow fadeInUp" data-wow-delay="0s">Our Consultancy</header></div>
            <div class="col-md-6">
                <div class="single-home-colsultant wow fadeInUp" data-wow-delay="0s">
                    <h2> <a href="<?php echo home_url();?>/student-consultancy/">Student Consultancy</a></h2>
                    <p>Australia is a worldwide popular destination for international students, particularly for Bangladeshi students when they look for higher education in abroad. Australia is a multicultural, safe, friendly, sophisticated and harmonious society in which students can learn and travel.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="single-home-colsultant wow fadeInUp" data-wow-delay="0.3s">
                    <h2><a href="<?php echo home_url();?>/migration-in-australia/">Migration in Australia</a></h2>
                    <p>Over a quarter of the Australian population were born overseas, and the population continues to grow with hundreds of thousands of people migrating to Australia annually.The Australian Immigration Department has over 100 visas to choose from, but one of the best ways to migrate to Australia is with a skilled visa.</p>
                </div>
            </div>
        </div>
    </div>
</section>