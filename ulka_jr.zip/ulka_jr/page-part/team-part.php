<section class="team-section-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="team-heading">
                    <header>Organizational Structure</header>
                </div>
                
                <div class="team-informations">
                    <?php
                    $args = array(
                        'post_type' => 'team',
                        'posts_per_page' => -1,
                        'order'   => 'ASC'
                    );
                    $i = 0;
                    $j = 1;
                    $jr_query = new  WP_Query( $args );
                    while ( $jr_query->have_posts() ) : $jr_query->the_post();
                    $img_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID,'thumbnail') );
                    $team_designation = get_post_meta( get_the_ID(), 'team_designation', true );     
                    
                    ?>
                       <div class="team-id-<?php echo get_the_ID();?> pull-left">
                            <div class="single-team wow fadeIn" data-wow-delay="0.<?php echo $i++;?>s">
                               <div class="team-img">
                                    <img src="<?php echo $img_url;?>" class="img-responsive" alt="">
                               </div>
                               <div class="team-info">
                                   <h4><?php echo get_the_title()?></h4>
                                   <span><?php echo $team_designation;?></span>
                               </div>
                            </div>
                        </div> 
                    <?php endwhile; wp_reset_query();?>
                </div>
                
                
            </div>
        </div>
    </div>
</section>