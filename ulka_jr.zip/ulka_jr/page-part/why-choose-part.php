<?php if(cs_get_option( 'why_choose_switch' ) == true):?>
<?php  $why_choose_title = cs_get_option( 'why_choose_heading_title' ); ?>
<?php  $why_choose_description = cs_get_option( 'why_choose_heading_description' ); ?>
<section class="why-choose-section">
   <div class="container">
       <div class="row">
           <div class="col-md-12">
               <div class="heading-title wow fadeInUp" data-wow-delay="0s">
                   <span><?php echo $why_choose_title?></span>
               </div>
               <div class="heading-description wow fadeInUp" data-wow-delay="0.2s">
                   <p><?php echo $why_choose_description;?></p>
               </div>
               <div class="why-choose-area">
                   <div class="row">
                        <?php
                        $why_choose_group = cs_get_option( 'why_choose_group' );
                        $i = 0;
                        foreach ( $why_choose_group as $key => $why_choose_groups ) { ?>
                          <div class="position-relative">
                           <div class="liner"></div>
                            <div class="col-xs-6 col-sm-3 col-md-3 why-choose-hover wow fadeInUp" data-wow-delay="0.<?php echo $i++;?>s">
                              <?php $pages = get_pages(); ?>
                               <div class="single-why-choose">
                                        <div class="single-why-choose-icon" rel="tooltip" title="<?php echo $why_choose_groups['why_choose_title'];?>">
                                           <img src="<?php echo wp_get_attachment_url( $why_choose_groups['why_choose_icon'] );?>" alt="">
                                        </div>
                                        <div class="single-why-choose-details">
                                           <h4><?php echo $why_choose_groups['why_choose_title'];?></h4>
                                        </div>

                               </div>
                            </div>
                            </div>
                        <?php } ?>
                   </div>
               </div>
           </div>
       </div>
   </div>
</section>
<script>
    jQuery(document).ready(function($){
        $('.single-why-choose').tooltip({
            selector: "div[rel=tooltip]"
        });
    });

</script>

<?php endif;?>