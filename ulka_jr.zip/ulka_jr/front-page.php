<?php
/**
 * The template for displaying front page
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Ulka_JR
 **/
get_header(); ?>
    <?php get_template_part( 'page-part/welcome-content', 'page' ); ?>
    <?php get_template_part( 'page-part/testimonial-part', 'page' ); ?>

<?php get_footer();?>