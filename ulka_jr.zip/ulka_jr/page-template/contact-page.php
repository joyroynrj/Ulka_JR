<?php /* Template Name: Contact Page */ ?>

<?php get_header(); ?>
<section class="contact-section">
    <div class="">
       <div class="contact-ifomation">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-sm-6 col-md-4">
                                <div class="contact-single-info wow fadeIn" data-wow-delay="0s">
                                    <div class="contact-icon">
                                        <img src="<?php echo get_template_directory_uri();?>/img/contact-address-icon.png" alt="">
                                    </div>
                                    <div class="contact-detail">
                                        <p><?php echo cs_get_option('address');?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="contact-single-info wow fadeIn" data-wow-delay="0.3s">
                                    <div class="contact-icon">
                                        <img src="<?php echo get_template_directory_uri();?>/img/contact-phone-icon.png" alt="">
                                    </div>
                                    <div class="contact-detail">
                                        <a href="tel:<?php echo cs_get_option('phone');?>"><?php echo cs_get_option('phone');?></a>
                                        <a href="tel:<?php echo cs_get_option('phone2');?>"><?php echo cs_get_option('phone2');?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="contact-single-info wow fadeIn" data-wow-delay="0.6s">
                                    <div class="contact-icon">
                                        <img src="<?php echo get_template_directory_uri();?>/img/contact-email-icon.png" alt="">
                                    </div>
                                    <div class="contact-detail">
                                        <a href="mailto:<?php echo cs_get_option('email');?>"><?php echo cs_get_option('email');?></a>
                                        <a href="mailto:<?php echo cs_get_option('email2');?>"><?php echo cs_get_option('email2');?></a>
                                    </div>
                                </div>
                            </div>
<!--
                            <div class="col-md-3">
                                <div class="contact-single-info wow fadeIn" data-wow-delay="0.9s">
                                    <div class="contact-icon">
                                        <img src="<?php echo get_template_directory_uri();?>/img/contact-fax-icon.png" alt="">
                                    </div>
                                    <div class="contact-detail">
                                        <a href="tel:<?php echo cs_get_option('fax');?>"><?php echo cs_get_option('fax');?></a>
                                        <a href="tel:<?php echo cs_get_option('fax2');?>"><?php echo cs_get_option('fax2');?></a>
                                    </div>
                                </div>
                            </div>
-->
                        </div>
                    </div>   
                </div>
            </div>
        </div>
        <div class="contact-map-area"></div>
        <div class="contact-form-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="contact-form-heading wow fadeInUp" data-wow-delay="0s">
                            <header>Contact Form</header>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="contact-form wow fadeIn" data-wow-delay="0.5s">
                            <?php echo FrmFormsController::get_form_shortcode( array( 'id' => 6, 'title' => false, 'description' => false ) ); ?>
                        </div>
                    </div>
                    <div class="col-md-4 visible-md visible-lg">
                        <div class="contact-img wow fadeIn" data-wow-delay="1s">
                            <img class="img-responsive" src="<?php echo get_template_directory_uri();?>/img/contact-img.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>

