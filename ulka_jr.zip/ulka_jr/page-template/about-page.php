<?php /* Template Name: About Page */ ?>

<?php get_header(); ?>

<?php 
$page_layouts = get_post_meta( get_the_ID(), '_page_sidebar_layouts', true );
$fullwidth = $page_layouts ['page_sidebar_select'] == 'fullwidth';
$left_sidebar = $page_layouts ['page_sidebar_select'] == 'left_sidebar';
$right_sidebar = $page_layouts ['page_sidebar_select'] == 'right_sidebar'; 
?>

<section class="">
    <div class="about-section">
        <div class="container">
            <div class="row">
               <?php if( $left_sidebar ):?>
                <div class="col-xs-12 col-md-4">
                     <?php get_sidebar('page');?>
                </div>
                <?php endif;?> 
                <div class="<?php if( $fullwidth ):?> col-md-12 <?php else:?> col-md-8<?php endif;?>">
                <div class="row">
               <?php if(have_posts()): while(have_posts()): the_post();
                 $img_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID,'thumbnail') );
                ?>
                <div class="col-md-12 wow fadeInUp" data-wow-delay=".2s">
                    <div class="about-information">
                      <?php the_content();?>
                    </div>
                </div>
<!--
                <div class="col-md-6">
                    <div class="about-img wow fadeInUp" data-wow-delay="0s">
                        <img src="<?php echo $img_url;?>" alt="" class="img-responsive">
                    </div>
                </div>
-->
                <?php endwhile; endif;?>
                </div>
                </div>
                <?php if( $right_sidebar ):?>
                    <div class="col-xs-12 col-md-4">
                        <?php get_sidebar('page');?>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
</section>
<?php get_template_part( 'page-part/mission-vision-part', 'page' ); ?>
<?php// get_template_part( 'page-part/team-part', 'page' ); ?>
<?php get_footer(); ?>

