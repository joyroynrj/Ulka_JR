<?php
/**
 * Template Name: Service Single Page
 */

get_header(); ?>
<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
        <section class="page-section-area single-course-page-section">
           <div class="container">
              
               <?php while ( have_posts() ) : the_post();
               $img_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID,'thumbnail') );
               $course_page_options = get_post_meta( $post->ID, 'course_page_optionss', true ); 
               ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="course-single-page-img">
                            <img class="img-responsive" src="<?php echo $img_url;?>" alt="">
                        </div>
                    </div> 
                    <div class="col-md-4">
                        <div class="course-class-information">
                           <span>Class Info</span>
                           <div class="class-table">
                            <table>
                                <tbody>
                                    <tr><td>Start Date:</td><td><?php echo $course_page_options['course_start_date'];?></td></tr>
                                    <tr><td>Class Duration:</td><td><?php echo $course_page_options['course_class_duration'];?></td></tr>
                                    <tr><td>Level:</td><td><?php echo $course_page_options['course_level'];?></td></tr>
                                    <tr><td>Years Old:</td><td><?php echo $course_page_options['course_year_old'];?></td></tr>
                                    <tr><td>Seat Avaiable:</td><td><?php echo $course_page_options['course_seat_available'];?></td></tr>
                                    <tr><td>Price:</td><td><?php echo $course_page_options['course_price'];?></td></tr>
                                </tbody>
                            </table>
                            </div>
                            <div class="apply-now-btn">
                                <a href="#">Apply now</a>
                            </div>
                        </div>
                    </div> 
               </div>
               <div class="row">
                   <div class="col-md-12">
                       <div class="course-page-content">
                           <?php echo the_content();?>
                       </div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-12">
                       <div class="course-tab-information">
                           <ul class="nav nav-tabs">
                              <li class="active"><a href="#description" data-toggle="tab" aria-expanded="true">Description</a></li>
                              <li class=""><a href="#course_info" data-toggle="tab" aria-expanded="false">Course Info</a></li>
                              <li class=""><a href="#teachers" data-toggle="tab" aria-expanded="false">Teachers</a></li>
                            </ul>
                            <div id="myTabContent" class="tab-content">
                              <div class="tab-pane fade active in" id="description">
                               <?php echo wpautop( $course_page_options['course_description'] ); ?>
                              </div>
                              <div class="tab-pane fade" id="course_info">
                                <?php echo wpautop( $course_page_options['course_info'] ); ?>
                              </div>
                              <div class="tab-pane fade" id="teachers">
                               <?php echo wpautop( $course_page_options['course_teacher'] ); ?>
                              </div>
                              
                            </div>
                       </div>
                       <div class="apply-now-btn-body">
                            <a href="#">Apply now</a>
                        </div>
                   </div>
               </div>
            <?php  endwhile;?>
            </div>
        </section>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer();?>