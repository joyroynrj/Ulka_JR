<?php /* Template Name: Course Page */ ?>

<?php get_header(); ?>

<?php 
$page_layouts = get_post_meta( get_the_ID(), '_page_sidebar_layouts', true );
$fullwidth = $page_layouts ['page_sidebar_select'] == 'fullwidth';
$left_sidebar = $page_layouts ['page_sidebar_select'] == 'left_sidebar';
$right_sidebar = $page_layouts ['page_sidebar_select'] == 'right_sidebar'; 
?>

<section class="page-section-area">
    <div class="about-section">
        <div class="container">
            <div class="row">
               <?php if( $left_sidebar ):?>
                <div class="col-xs-12 col-md-4">
                     <?php get_sidebar('page');?>
                </div>
                <?php endif;?> 
                <div class="<?php if( $fullwidth ):?> col-md-12 <?php else:?> col-md-8<?php endif;?>">
               <?php if(have_posts()): while(have_posts()): the_post();
                 $img_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID,'thumbnail') );
                ?>
                    <div class="course-page-content">
                      <?php the_content();?>
                    </div>
                <?php endwhile; endif;?>
                <div class="course-page-section">
                    <div class="">
                        <?php
                        $course_group = cs_get_option( 'course_group' );
                        $i = 2;
                        $j = 0;
                        foreach ( $course_group as $key => $course_groups ) { ?>

                           <?php if($i%2==0):?>
                            <div class="single-training">
                                <div class="row" >
                                    <div class="col-md-6" >
                                        <div class="wow fadeIn" data-wow-delay=".0s">
                                        <div class="single-course-img">
                                            <img class="img-responsive center-block" src="<?php echo wp_get_attachment_url( $course_groups['course_img'] );?>" alt="">
                                        </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 ">
                                       <div class="single-training-info wow fadeIn" data-wow-delay=".2s">
                                        <div class="single-training-title">
                                            <span><h3><?php echo $course_groups['course_title'];?></h3></span>
                                        </div>
                                        <div class="single-training-des">
                                            <?php echo $course_groups['course_short_des'];?>
                                        </div>
                                        <div class="single-course-btn">
                                            <a href="<?php echo get_page_link( $work_groups['course_page'] );?>"><span>Apply Now</span></a>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php else:?>
                            <div class="single-training">
                            <div class="row">
                               <div class="col-md-6 visible-xs visible-sm">
                                   <div class="wow fadeIn" data-wow-delay=".6s">
                                    <div class="single-course-img">
                                        <img class="img-responsive center-block" src="<?php echo wp_get_attachment_url( $course_groups['course_img'] );?>" alt="">
                                    </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="single-training-info  wow fadeIn" data-wow-delay=".4s">
                                    <div class="single-training-title">
                                        <span><h3><?php echo $course_groups['course_title'];?></h3></span>
                                    </div>
                                    <div class="single-training-des">
                                        <?php echo $course_groups['course_short_des'];?>
                                    </div>
                                    <div class="single-course-btn">
                                        <a href="<?php echo get_page_link( $work_groups['course_page'] );?>"><span>Apply Now</span></a>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-md-6 visible-md visible-lg">
                                   <div class="wow fadeIn" data-wow-delay=".6s">
                                    <div class="single-course-img">
                                        <img class="img-responsive center-block" src="<?php echo wp_get_attachment_url( $course_groups['course_img'] );?>" alt="">
                                    </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <?php endif;?>
                            <?php $i++;?>
                        <?php } ?> 
                    </div>
                </div>
                </div>
                <?php if( $right_sidebar ):?>
                    <div class="col-xs-12 col-md-4">
                        <?php get_sidebar('page');?>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>

